# 01: Change value

**Status:** wontfix
**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.
