---
name: create-next-agent-prompt
description: Create or refresh next_agent_prompt.md with an eligible implementation handoff or QA checkpoint status, on request or after a local Markdown ticket is fully completed.
---

# Create next-agent prompt

Write a self-contained implementation handoff using [implement-with-checkboxes](../implement-with-checkboxes/SKILL.md), or a QA handoff/waiting status when work reaches a human checkpoint. Save it to `next_agent_prompt.md` at the repository root unless the user specifies another destination. Creating the prompt does not start another implementation, QA session or harness run.

## Select the ticket

1. Read applicable `AGENTS.md` instructions and the repository's issue-tracker, readiness, and domain guidance. Inspect the worktree and any existing destination file; preserve unrelated changes. Use the feature and completed ticket supplied by the caller, or the user's explicit target. Ask for the feature only if repository context cannot identify it.
2. Read the approved spec/proposal, milestone membership/order and QA records, feature index, ticket headers, and needed completion evidence. Use the [shared planning reference](../references/planning.md#milestone-membership) for membership and approval boundaries and [ticket numbering](../references/planning.md#ticket-numbering) for ordering conventions. A readiness label alone is not prerequisite completion, and `Blocked by:` remains dependency history even after prerequisites finish. Verify completion from criterion evidence, checks, independent reviews, and implementation/bookkeeping commits rather than ticket numbers or header status alone. Missing or contradictory membership, order or acceptance evidence is a blocker to resolve, not permission to infer eligibility.
3. Identify the earliest required milestone whose human acceptance remains pending. Later milestones stay ineligible until the preceding required work is verified complete and its human acceptance is recorded for the assessed candidate. Within the eligible group, select open, unclaimed, agent-ready work with genuinely completed prerequisites in the approved preferred order. Honor explicit user selection and documented independent-experiment priorities within their eligibility rules. An older lower-numbered ticket cannot bypass plan order or QA gates. For an explicit but ineligible target, report its blockers instead of generating an executable assignment; do not silently substitute another feature or ticket.
4. When that group's required tickets are complete but its QA is pending, write the checkpoint handoff below, holding later required milestones. If remaining work has prerequisite/readiness blockers, write an explicit waiting status with evidence links. All tickets Done while final QA is unaccepted means **awaiting final QA**, not feature completion. Report feature completion only with verified required work and recorded final acceptance. Keep independent experiments' acceptance and priority separate as the approved plan defines them. Replace a stale generated execution prompt with the correct handoff/status.

## Gather focused context

For eligible implementation work, read the selected ticket, its referenced spec sections, relevant glossary/ADRs, current public contracts, documented checks, and prerequisite completion evidence. Inspect implementation entry points or existing tests only as needed to make the handoff concrete. Use the feature's context policy; do not replay sibling transcripts or load unrelated spec sections by default. At a checkpoint, gather the milestone QA context for the QA/status branch instead.

Identify every acceptance criterion, the public testing seam, compatibility requirements, explicit scope exclusions, and any unresolved decisions. Use the existing approved testing seam when one exists; otherwise tell the next agent to establish it with the user before writing tests. Preserve requirement wording and scope when translating criteria into implementation instructions.

Apply the [development review contract](../../../../docs/agents/review-records.md)
to ownership, preparation/repair, findings and architecture checkpoints in either
handoff branch. Carry its required source/scope/history and next responsible action,
plus recorded rounds, repeated failures, agreed bounds and outstanding preparation.
Direct fresh reviewers to that contract. Missing/incomplete/stale required review
holds affected integration/readiness; completed tickets with missing cumulative work
receive a preparation/waiting status. Review completion never supplies QA acceptance.

For refactors 20–24 and M1, carry the [historical G2/C5 identity and limits](../evaluate-reviewers/SKILL.md#repository-evaluation-history).
Preserve original corpus/reports and finite results separately from current source
review, cumulative assessment and human QA; this adds no calibration assignment.

## Draft an implementation prompt

Write directly to the next agent, beginning with `Use $implement-with-checkboxes to implement only:` and the exact repository-relative ticket path. Include the ticket title, exact scoped spec references, and enough project-specific context to work without the preceding conversation. Use the current skills and tracker rules; keep detailed invariant workflows in their authoritative sources while making the consequential gates explicit in the handoff:

- **Starting state:** Follow `AGENTS.md`; capture the next agent's starting HEAD as its fixed review baseline; inspect/preserve the worktree; verify prerequisite implementation and completion evidence. Historical commit references are context, not a replacement for capturing that baseline.
- **Eligibility and role settings:** Name the approved plan and current milestone, selection evidence and next human boundary. Carry the agreed model, role guidance and context target using the [role and testing contracts](../references/planning.md#role-and-testing-contracts): worker and repair default to Medium with explicit ticket worker overrides applied to both; Spec and Standards default independently to High. Report missing model/configuration rather than guessing it. Require fresh assignments; a worker override does not change reviewer settings. Development settings do not claim runtime profile enforcement or skill capture.
- **Bounded implementation:** Cover every acceptance criterion with observable evidence, preserve existing passing/rejection behavior, document affected contracts, and name the deferred neighboring features. Do not expand the ticket or resolve an architectural decision the human still owns.
- **Environment and tests:** Read the repository's environment guidance before Python, dependency installation, or checks and use its reusable environment. Reference its testing policy and [test-strategy](../test-strategy/SKILL.md): map existing coverage before adding tests, select focused checks, and plan evidence capture during required verification. For executable behavior use `$tdd` at the agreed public seam, one failing behavioral test followed by its implementation per slice. Name the project's actual fixture/process/repository requirements and observable success/failure evidence. Preserve required complete-suite and explicit ticket checks. For standalone documentation/skill changes, carry the policy's document, link, routing and workflow validation; keep detailed check-selection and evidence-reuse rules in the testing policy.
- **Committed review:** After checks pass, commit only the implementation before `$code-review`, whose committed-diff review cannot see uncommitted work. Supply the captured baseline, ticket, and relevant spec requirements explicitly. Obtain separate fresh Spec and Standards reviews with their independent settings; fixture reviewers are not substitutes. For test changes, supply the coverage map, testing policy, and test-strategy's review guidance to these existing reviewers. Resolve blocking findings through fresh repair assignments with the worker setting, rerun affected required checks, commit repairs, and re-review the whole implementation against the original baseline. Record optional suggestions separately.
- **Completion bookkeeping:** After verified implementation and reviews, reconcile acceptance markers, set `**Status:** completed`, retain prior readiness in the completion comment, and preserve `Blocked by:`. Record implementation commits, criterion-specific evidence, actual checks, independent review outcomes, and unresolved items; link evidence from the feature index. Commit only this ticket's bookkeeping separately from implementation. If verification fails, leave unverified criteria unchecked and report the exact blocker.
- **Next handoff:** After implementation and bookkeeping are committed and fully complete, follow the implementation skill's automatic `$create-next-agent-prompt` step, including its separate handoff commit and final report. Select through milestone eligibility again; at a human boundary create a QA handoff/waiting status. Ticket completion and plan approval do not accept milestones or complete the feature before final QA.
- **Boundaries and report:** Keep each agent within the applicable context target (250K active context for this feature unless changed by the user). Preserve approved inputs belonging to an active harness run and report that condition as a blocker to mutations. Do not push without explicit authorization. Report implementation/bookkeeping commits, check and review outcomes, unchecked criteria, and the next prompt path or exact handoff blocker. Claim completion only when the required gates actually passed.

Adapt these instructions to the selected ticket rather than copying the previous ticket's criteria, exclusions, expected results, or test counts. Link prerequisite evidence instead of treating old outcomes as proof of the new implementation.

## Draft a QA handoff or waiting status

Begin with the actual status, such as **Awaiting milestone QA**, **Awaiting final QA**, or **Waiting: prerequisite evidence missing**. Identify the approved plan/version, milestone and membership, verified completion evidence, pending acceptance/blockers and which later work remains ineligible. Use the milestone's planned human checks, setup, expected observations and acceptance conditions; distinguish development checkpoints from target-repository runtime QA in fixtures.

Carry outstanding review work and the inspected/omitted scope using the shared
[ownership and review-scope contract](../../../../docs/agents/review-records.md#repair-progression-and-handoff),
including unresolved full finding keys, missing reports, pending revalidation and
human decisions or their explicit absence. Keep the next responsible action
visible without treating review completion as QA acceptance.

Carry exact existing QA request and artifact paths/identities, run identity, feature revision, development base, tested candidate revision, gate evidence, decision location and recorded decision when available. Label missing references explicitly; a plan without runtime artifacts receives a preparation/waiting status with the missing inputs and next responsible workflow, not invented request IDs, candidates, results or acceptance. Identify a known stale/mismatched decision as pending renewed assessment. Link actual records without authoring or altering an approval artifact.

Keep candidate preparation, promotion, continuation, QA-session execution and approval authority with their separately authorized workflows. State the next human/workflow action without launching it. An implementation or repair worker cannot accept a candidate. Only recorded human acceptance of the assessed inputs can satisfy the checkpoint; changed inputs require renewed acceptance under the approved contract.

## Save and verify

Write the actual prompt as Markdown, without an enclosing code fence or unresolved template placeholders. Refresh an existing generated handoff; preserve unrelated user-authored content or edits, using a separate destination and reporting the conflict if they cannot be retained safely.

Read the saved file back. Check every ticket/spec/evidence path, criterion coverage, milestone/prerequisite eligibility, role settings, scope boundaries, and consistency with the current implementation skill. For QA/status outputs check that known request/candidate/artifact identities are exact, missing inputs remain explicit, and no approval is inferred. An ineligible or QA-pending handoff must clearly identify its status, without instructing the next milestone to execute.

Return the destination, selected ticket and selection reason, or the checkpoint/blocker/verified-complete status. When invoked by `implement-with-checkboxes`, leave committing the generated handoff to that caller; when invoked directly, commit only if requested. Never launch the next agent as part of this skill.
