import os, subprocess
from pathlib import Path
stage=os.environ['TICKET_HARNESS_STAGE']
print(stage, subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
assert Path('value.txt').read_text()==('1\n' if stage=='baseline' else '2\n')
if stage!='baseline':
    assert Path('work-01').read_text()=='delivered 01\n'
if Path('work-02').exists():
    assert Path('work-02').read_text()=='delivered 02\n'
