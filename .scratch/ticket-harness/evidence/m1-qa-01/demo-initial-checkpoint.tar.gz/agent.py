import json, os, sys
from pathlib import Path
a=json.load(sys.stdin)
r={k:a[k] for k in ('role','ticket','attempt','base_revision','revision')}
r['pid']=os.getpid()
with Path('/tmp/ticket-harness-m1-human-qa-yjwh5cr2/launches.jsonl').open('a') as out:
    out.write(json.dumps(dict(ticket=a['ticket'],role=a['role'],attempt=a['attempt'],pid=os.getpid()))+'\n')
if a['role']=='implementation':
    Path('value.txt').write_text('2\n')
    Path('work-'+a['ticket']).write_text('delivered '+a['ticket']+'\n')
    r.update(result='submitted',summary='Delivered '+a['ticket'],changed_files=['value.txt','work-'+a['ticket']],checks=[],acceptance_evidence=['Delivered requested work'],unresolved_questions=[])
else:
    r['findings']=[]
print(json.dumps(r))
