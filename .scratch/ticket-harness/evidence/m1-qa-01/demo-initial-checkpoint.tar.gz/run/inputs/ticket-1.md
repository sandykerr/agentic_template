# 02: Deliver second work

Status: ready-for-agent
Blocked by: 01
Checks: ticket

## Acceptance criteria

- [ ] Deliver work 02.
