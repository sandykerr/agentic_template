# 01: Preserve captured input (synthetic)

**Status:** ready-for-agent

**Plan:** synthetic-plan-v1, synthetic approval assumed only for this example.
**Milestone:** [MX](../milestones.md).

Authorized repair changes the two synthetic source statements to yes. Initial
source `f7bcc9003fa791f0572b9ef9771a0a0b270ab249`, repair `9fc05a9f920a43e01e9b2087f2efff2686ba7952`, later changed source `770a82901602f034ae10f0983b6bc4378f7bb72d` are [saved](../evidence/commits.md).
This readiness label is unaffected by the review lifecycle.

## History

- [Ticket assessment](../reviews/ticket-01.md), [original concern](../evidence/spec-01.md#f1),
  [repair and verification](../reviews/history.md#e03).
- [Cross-ticket assessment](../reviews/architecture-MX.md) links this ticket and follow-up.
