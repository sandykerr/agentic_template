# 01: Preserve captured input (synthetic)

**Status:** ready-for-agent

**Plan:** synthetic-plan-v1, synthetic approval assumed only for this example.
**Milestone:** [MX](../milestones.md).

Authorized repair changes the two synthetic source statements to yes. Initial
source `cf8c8dd3500296be6e119458cbe880c10210cbda`, repair `4672f236a30f97f89d37d7c39bad7ce1c1c04f3f`, later changed source `17c630067251df60a11dadb4d07daa42cadf06ae` are [saved](../evidence/commits.md).
This readiness label is unaffected by the review lifecycle.

## History

- [Ticket assessment](../reviews/ticket-01.md), [original concern](../evidence/spec-01.md#f1),
  [repair and verification](../reviews/history.md#e03).
- [Cross-ticket assessment](../reviews/architecture-MX.md) links this ticket and follow-up.
