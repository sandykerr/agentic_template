# Python development environment

Use [`environment.yml`](../../environment.yml): Python 3.12, pip, and pytest.
Put project dependencies in packaging metadata when it exists, and shared
development tools in `environment.yml`.

## Use the existing environment

From the checkout being developed, run without shell activation:

```bash
export XDG_CACHE_HOME=/home/ajkerr1/development/agentic_template/.micromamba/cache
micromamba run --prefix /home/ajkerr1/development/agentic_template/.micromamba/envs/dev python --version
micromamba run --prefix /home/ajkerr1/development/agentic_template/.micromamba/envs/dev python -m pip --version
micromamba run --prefix /home/ajkerr1/development/agentic_template/.micromamba/envs/dev python -m pytest
```

Set `XDG_CACHE_HOME` in each new shell using `micromamba run`: its process locks
need a writable cache, and the sandbox's default home cache may be read-only.
For simple Python invocations, the environment's absolute `bin/python` also works
without micromamba or this setting. Use the environment's interpreter for
`python -m pip` and `python -m pytest`. Run documented repository checks when
implementation supplies them; environment setup does not add a test suite.

## Create or update an environment

From a new clone's root:

```bash
micromamba --no-rc --root-prefix "$PWD/.micromamba" create --yes --prefix "$PWD/.micromamba/envs/dev" --file environment.yml
```

After changing `environment.yml`, update an existing environment:

```bash
micromamba --no-rc --root-prefix "$PWD/.micromamba" install --yes --prefix "$PWD/.micromamba/envs/dev" --file environment.yml
```

The ignored `.micromamba/` holds the environment and package cache. Creation and
package changes require network access to conda-forge. The Python minor version
constraint is not an exact package lock. Use the new clone's absolute prefix and
cache path afterward.

## Worktrees and agents

Reuse the shared absolute prefix above across agents/worktrees; relative
`.micromamba/` paths point into the current checkout. Keep Python/test commands'
working directory in the checkout being developed and use its source or documented
test configuration for local imports.

An editable install in the shared environment points at one checkout. For an
isolated editable install or different dependency versions, create a separate
environment in that worktree with the command above. Reuse the shared environment
for execution; coordinate package changes across agents.
