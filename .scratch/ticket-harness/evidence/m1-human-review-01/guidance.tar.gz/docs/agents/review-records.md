# Review records

Apply this Markdown record contract when assigning reviews, saving reports,
disposing findings or carrying them into repairs/handoffs. It implements the
[approved review contract](../../.scratch/ticket-harness/spec.md#review-work-findings-and-decisions)
and [tracker conventions](issue-tracker.md), without a runtime schema, scheduler
or new gate. [Ownership/scope](ownership-review.md) owns substantive inspection;
[architecture checkpoints](architecture-checkpoints.md) own progression gates.

## Location and navigation

Use `.scratch/<feature>/reviews/` for assessments, histories and decisions, and
`.scratch/<feature>/evidence/` for immutable reports, instruction snapshots and
checks. Link the review index from the feature index and originating ticket
history. Routine ticket Spec/Standards reports share an assessment; cross-ticket
work gets its own, linked to every originating ticket and milestone. Review IDs
such as `review-ticket-16` or `review-M1-architecture-01` are independent of ticket
numbers and do not select implementation work.

Copy the [assessment](../templates/reviews/assessment.md),
[report envelope](../templates/reviews/report.md),
[finding history](../templates/reviews/history.md) and
[human decision](../templates/reviews/decision.md) templates. Replace every
placeholder with a value or explicit absence/reason and paths with relative links.
If an envelope would alter reviewer output, attach that output verbatim separately.
Historical reports keep their format/scope without retroactive attestations.
See the [review index](../../.scratch/ticket-harness/reviews/README.md) and
[isolated example](../../.scratch/ticket-harness/evidence/16-miniature/README.md).

Maintain navigable links, including return links where needed:

`ticket/milestone → assessment → report/finding/evidence → history/decision → repair ticket/commit → independent verification → milestone assessment`.

For absent repair, decision or milestone work, record the gap and responsible next
action; links must not imply unperformed assessment or approval.

## Assessment identity and lifecycle

Identify purpose, originating tickets, approved plan/milestone, fixed original
baseline, exact assessed revisions and reviewer axes/assignments. Record actual
model/reasoning/context settings and instruction identities: revision/path plus
digest or snapshot, including supplied spec/ticket/guidance. Mark unavailable
settings; intended configuration alone does not prove actual delivery.

Record inspected files/flows, omissions/reasons, unresolved assumptions,
report/evidence links and current findings keyed below. Preserve the baseline
through repairs; each later report identifies its own exact source/assignment.
A new clean report never rewrites the earlier assessment.

**Review lifecycle:** `planned`, `in progress`, `completed`. Completed means the
defined inspection/reports finished; a missing required report means in progress.
Keep outstanding findings, pending revalidation and integration/milestone
eligibility separate. Lifecycle is independent of ticket `Status:`, execution
state, verified completion and QA acceptance; completed assessments may have
open findings.

## Immutable reports and append-only history

Save each original report/evidence snapshot at a unique path, identifying report,
axis/attempt/assignment, baseline, assessed source and content. Record its digest
in an index/manifest outside itself. Actor/content attribution supplies provenance
without signing infrastructure. Preserve rejected/failed attempts too.

A full finding key is `(review ID, report ID, report-local finding ID)`. Display
with `/`, using IDs without `/`: `review-ticket-16/spec-01/F1` differs from
`review-ticket-16/standards-01/F1` and `review-ticket-16/spec-02/F1`. Link superseding
or reopened observations to their prior full key; local IDs alone are insufficient.

Append uniquely identified/numbered events with full key, disposition, actor/role,
reason, evidence and affected revision. Link prior/superseded observations,
decisions/amendments, repair ticket/commit, independent verification and milestone
assessment as applicable; explain pending/not-applicable links. Correct mistakes
by appending a superseding event. Original reports/evidence/events remain intact;
the assessment's mutable current summary may be refreshed from this history.

## Dispositions and authority

| Disposition | Required support/action |
| --- | --- |
| `open` | Original/reopened concern, evidence and impact; authorized repair or pending decision. |
| `fixed` | Authorized repair/ticket, exact commit and independent verification of that revision/concern. Worker assertions or mechanical checks alone are insufficient. |
| `deferred to linked ticket` | Follow-up ticket, reason, original optional/blocking classification and authority. Optional work can defer within scope; blockers require an explicit human decision and any required approved amendment. |
| `accepted with reason` | Reason, affected source/risk and authority; consequential risk needs an explicit human review decision. |
| `awaiting human decision` | Concrete question, consequence, options, source/evidence; remain unresolved until decided. |

Preserve original severity/classification; dispositions cannot silently downgrade
blockers. Changed source requires a pending-revalidation/reopened event and summary
update before citing an old fix as current. Independent revalidation names the
new exact revision/concern and appends its result, preserving the earlier fix.
Renew applicable assessments/QA under the approved contract. Unchanged/irrelevant
evidence may be cited at its original scope; it cannot replace missing revalidation.

Agents may perform authorized repairs and record observations/proposals. Actual
human decisions own consequential risk acceptance, blocker deferral, ownership
changes and scope expansion. Preserve the human statement and attribution/context;
link any required approved amendment. A missing amendment keeps the blocker
unresolved under that contract. Disposition alone cannot authorize integration,
resume a stopped run or grant promotion. Follow existing eligibility rules and
keep review decisions separate from
[exact-candidate QA](../adr/0002-human-qa-gates-feature-promotion.md).

## Active runs and preserved evidence

Outside runs, author records/navigation in the feature tracker while preserving
historical reports, completed-ticket requirements and frozen QA evidence. During
runs, write only to harness-owned output outside approved inputs and worker-editable
source; preserve captured inputs/identities. Link outputs from tracker history
afterward. If the requested authoring file is an active input, report that blocker
and retain the record in authorized output until authoring is permitted.

Reviewer calibration and runtime adoption remain separate tickets 19/33;
development guidance/templates do not establish runtime enforcement or evidence
that has not been collected.
