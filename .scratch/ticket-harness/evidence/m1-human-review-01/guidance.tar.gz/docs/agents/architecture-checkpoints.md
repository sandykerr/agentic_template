# Development architecture checkpoints

Apply this contract during implementation, integration preparation and milestone
QA handoff. It implements the approved
[cumulative checkpoint contract](../../.scratch/ticket-harness/spec.md#cumulative-architecture-checkpoints).
Runtime enforcement belongs to ticket 33. Follow [ownership/scope](ownership-review.md)
for substantive inspection and [review records](review-records.md) for identities,
immutable reports, finding history and authority.

## Decide when review is required

At **ticket start and after implementation**, record yes/no with source evidence
for each trigger: new lifecycle, persistence/restoration path, shared mutable state
or additional writer. Include guidance state when prose introduces these
responsibilities. Explain unchanged owners and affected callers, writers,
consumers, restore/invalidation paths. Any trigger requires broader assessment of
that workflow **before ticket integration**; missing/incomplete work blocks it.
Routine independent Spec/Standards still run. No trigger means no unconditional
third reviewer. Reassess repairs when scope changes the trigger result.

Before **each required development milestone QA request**, create cumulative work
in the feature review index, before ready claims or assessment-evidence freeze.
Early work may be `planned`; missing reports remain explicit. Required membership
completion alone yields a preparation/waiting handoff until this checkpoint and
other candidate gates pass.

## Pin the cumulative work

Use the [assessment template](../templates/reviews/assessment.md). Include:

- Purpose, originating milestone/tickets, start/post-change trigger evidence and
  integration/QA gate.
- **Cumulative baseline:** exact last human-accepted milestone source with actual
  QA decision; for the first milestone, exact feature-start revision with
  Git/planning provenance. Keep it distinct from the ticket's fixed starting
  review baseline. Clean reviews do not establish acceptance; the repository's
  first commit needs feature provenance. Missing/ambiguous source or acceptance
  holds readiness until the responsible workflow resolves it.
- Exact assessed commit and source/instruction identities; complete file/workflow
  inventory, omissions/reasons. In this small repository inspect **all
  `ticket_harness` Python files**, including unchanged collaborators; larger targets
  inspect the complete affected workflow/collaborators. A file list is not inspection.
- Prior unresolved full finding keys, original reports, disposition/decision/
  amendment/verification links and pending exact-source revalidation. When there are none, state
  that explicitly; retain optional/deferred observations.

Assign **fresh High Standards**, using the approved model, role guidance and
active-context target; report unavailable settings. Keep it distinct from routine
ticket attempts and their independent axes. Architecture guidance may inform it;
HTML is optional. Explain actual owners/operations, unchanged writers/consumers,
restoration/invalidation. Trace concrete edits for a plausible change (such as a
new review stage or repair policy): affected owner, callers, saved representation,
restore, invalidation and checks, with reasons. Hashes/tests support identity or
observed behavior, separately from design judgment.

Reuse an audit only with proof of **exact source, complete required coverage and
retained dispositions**, linked to its original. Changed source needs renewed
relevant review naming the current source; explain any applicable unchanged
evidence. Prior readiness stays stale until then. Preserve original reports.

## Findings and progression

Apply [disposition/authority rules](review-records.md#dispositions-and-authority),
including exact independent fix verification, linked follow-up, actual human
authority/amendments and source revalidation. Missing decisions/amendments remain
unresolved; original classifications/history survive. Optional suggestions cause
no automatic repair or approval request.

Record four separate source-supported observations:

| Observation | Meaning/action |
| --- | --- |
| Assessment completed | Required inspection/reports finished; findings may remain. Missing reports mean in progress. |
| Findings resolved/dispositioned | Exact verified fixes or valid authority/follow-up. Open in-scope blockers prevent affected integration/readiness. |
| Candidate ready for human QA | Membership, current architecture work, finding gates and all existing exact-candidate checks pass. Only the authorized QA workflow prepares the request. |
| Milestone accepted | Actual human QA accepts exact candidate/inputs, permitting subsequent milestone/promotion under the approved workflow. |

Clean checkpoints progress autonomously within scope without granting acceptance.
Use existing bounded repairs for authorized in-scope blockers. Cumulative blockers
outside those bounds or undecided consequential contracts preserve work in an
incomplete human-decision handoff; unaffected work follows existing eligibility.
A review decision cannot resume stopped runs or accept candidates.

## Tracker and handoff

Link work from originating tickets, milestone and review index. Carry baseline/
current source, complete scope, lifecycle/missing reports, unresolved full keys,
deferred tickets, decisions/amendments, stale evidence and responsible next action
into implementation and QA/waiting handoffs. Distinguish absent from clean work;
refresh summaries while preserving originals/history.

Follow [active-run preservation](review-records.md#active-runs-and-preserved-evidence):
new run artifacts belong in authorized output; tracker links wait until authoring
is allowed. Changed source or frozen evidence invalidates relevant readiness;
new proposals can stay outside frozen evidence pending renewed review/request.
The [ticket 18 walkthrough](../../.scratch/ticket-harness/evidence/18-walkthrough/README.md)
is finite isolated evidence with synthetic human statements, not assessment or
acceptance of the real development milestone.
