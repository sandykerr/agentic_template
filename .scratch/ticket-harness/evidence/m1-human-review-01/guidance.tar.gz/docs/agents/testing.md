# Testing policy

For harness development, use [test-strategy](../../.agents/skills/custom/test-strategy/SKILL.md)
for coverage selection and suite audits, and [TDD](../../.agents/skills/matt-pocock/tdd/SKILL.md)
for implementation. Before Python or checks, read [environment guidance](python-environment.md).
The [harness guide](../ticket-harness.md#python-and-checks) supplies commands and tool setup.

## Coverage selection

Before adding cases, map acceptance requirements to existing tests; reuse or extend
their coverage. For each new case, identify its distinct failure. Keep the short
map in the ticket's evidence or implementation report.

The approved seam is the public CLI with scripted external processes, real
temporary Git repositories, and observable Git/report outcomes. A cheaper public
module seam requires a design decision with the human; preserve behavioral
coverage rather than replacing it with internal mocks.

Cover meaningful role, attempt, failure-policy differences and interactions.
Use representative equivalent inputs rather than every dimensional combination;
explicit ticket scenarios and demonstrated regressions remain required. One
scenario or assertion may support several criteria; separate test names do not
establish distinct coverage. Preserve isolated writable repositories when sharing
fixture builders or setup helpers.

## Which checks to run

| Change or stage | Verification |
| --- | --- |
| Development iteration | Focused behavioral and affected caller/fixture tests plus relevant static checks; expand when shared impact is uncertain. |
| Implementation ticket checkpoint | Full suite and required strict type, lint, format, and whitespace checks on the final implementation, plus explicit ticket checks. |
| Further code, test, configuration, or dependency changes | Rerun affected checks and renew full-suite completion for the final implementation. |
| Packaging or entry-point changes | Wheel/install and installed CLI checks; other installed scenarios when explicitly required or resolving concrete uncertainty. |
| Standalone documentation or skill changes | Validate documents/skills, links, routing, and relevant workflow decisions; runtime tests when executable examples or behavior are affected. |
| Bookkeeping or handoff after verified implementation | Validate records, links, and consistency; preserve implementation check provenance. Prose-only bookkeeping needs no suite replay. |

Focused passes do not replace an implementation ticket's full-suite gate or
explicit checks. Missing or failing required checks leave verification incomplete.

Select focused cases by behavior after confirming their relevance, for example:

```bash
python -m pytest tests/test_repairs.py -q -k failed_check
```

When investigating suite cost, collect timings during the required full run:

```bash
python -m pytest -q --durations=20
```

Inspect prerequisite completion records against the current implementation. Rerun
a prerequisite scenario for a specific compatibility uncertainty; the final full
suite already includes prerequisite regressions. Fresh reviewers may reproduce
selected behavior without each repeating the matrix.

## Evidence and review

Arrange evidence capture before checks. Record command, exit result, actual
source/test revision, relevant uncommitted changes, and retained log/artifact paths.
Reuse assertions/results across criteria and retain required CLI/Git evidence
from that execution. Extra saved JSON alone does not justify another complete
fixture run. Collect missing required observations with a scoped run; report
remaining gaps rather than infer unobserved results.

When tests change, give the coverage map and this policy to the existing Spec and
Standards reviewers. Their review covers test value, unnecessary combinations,
repeated setup, fixture ownership, isolation, and reliability. Maintenance
suggestions remain optional.

For requested or measured suite audits, use test-strategy. Map proposed
consolidations to surviving regression coverage and before/after check evidence.
Runtime and maintenance cost are useful measures; test count reduction alone is
not a goal.

## Harness verification remains separate

This development policy leaves every configured harness baseline, lightweight,
review, and exact-candidate gate in force. Source changes invalidate approvals
under existing rules. Development test selection or a prior passing tree cannot
authorize skipping required gates or reusing approval for a different candidate.
