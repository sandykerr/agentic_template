# Issue tracker: Local Markdown

## Conventions

- Feature directory: `.scratch/<feature-slug>/`; spec: `spec.md`; implementation tickets: `issues/<NN>-<slug>.md` within it.
- Number new bundles from `01` in preferred execution order across milestones, blockers first. Schedule independent experiments without artificial dependencies. Continue existing IDs for additions; refresh draft numbering when proposed order changes before approval. Preserve published IDs on revisions and explain ordering exceptions. Only on explicit human request, sequentially renumber published open tickets, updating filenames/live references together and retaining an old-to-new mapping. Historical definitions, completion evidence, and captured run inputs retain original identities.
- Dependencies, milestone gates, and documented priorities determine eligibility. Declare prerequisites by ticket number and title in `Blocked by:`; readiness does not establish dependency completion.
- Record [triage readiness](#triage-readiness) in a `Status:` line near the top of each open implementation ticket. [Verified completion](#completion-bookkeeping) replaces it with `Status: completed`.
- Append comments/conversation history under `## Comments`.

## Triage readiness

| Label | Meaning |
| --- | --- |
| `needs-triage` | A maintainer must evaluate the issue. |
| `needs-info` | More information is required. |
| `ready-for-agent` | Sufficiently specified for unattended agent implementation. |
| `ready-for-human` | Requires human implementation. |
| `wontfix` | Declined; will not be actioned. |

These labels describe authoring-time readiness, separate from harness execution
state. `completed` is terminal completion bookkeeping, not a triage label; retain
the previous readiness label in the completion comment.

## Publishing and fetching

A skill's instruction to publish means create the appropriate local Markdown
file. Fetch by referenced path or locate the numbered ticket within its feature.

## Harness execution

During a harness run, approved specs/tickets remain unchanged; the harness records
execution statuses, attempts, and outcomes separately from triage readiness.

## Review records

Before preparing review assignments, saving reports, recording finding decisions,
or carrying them into repairs/handoffs, read [review records](review-records.md)
for templates, assessment navigation, immutable evidence, and append-only finding
history. Review lifecycle is separate from readiness and human QA decisions.

For risk-triggered integration and development milestone readiness, apply
[architecture checkpoints](architecture-checkpoints.md). Keep cumulative work in
the feature review index with originating ticket/milestone links; carry missing
or stale reports and unresolved findings into handoffs. Ticket or assessment
completion alone establishes neither QA readiness nor acceptance.

## Completion bookkeeping

Outside an active harness run, reconcile tickets with verified outcomes:

- Mark an acceptance criterion `[x]` only with evidence for the current implementation and satisfied required checks/relevant independent reviews. Leave unverified criteria `[ ]` and explain gaps.
- Change checkbox markers only within acceptance criteria. Preserve criterion wording, scope, and declared dependencies, including `Blocked by:`.
- Once every criterion and required gate passes, set the header to `**Status:** completed` and record prior readiness in the completion comment. Otherwise retain readiness. This terminal bookkeeping status does not replace harness execution records.
- Append a completion comment under `## Comments`: implementation commits, evidence per criterion, actual check results, separate Spec and Standards review outcomes, and unresolved items. Link longer evidence instead of copying logs.
- Link completion evidence from the feature index when present. Before declaring completion, verify agreement among acceptance markers, header status, completion comment, and index.
- For approved inputs to an active harness run, defer all ticket/index bookkeeping until the run ends; preserve immutable snapshots and execution records.

## Wayfinding operations

For `wayfinder`, use `.scratch/<effort>/map.md` and child tickets in
`.scratch/<effort>/issues/`:

- Set child `Type:` to `research`, `prototype`, `grilling`, or `task`; name prerequisites in `Blocked by:`.
- A child is available when open, unclaimed, and all prerequisites resolved; choose the lowest number first.
- Claim with `Status: claimed`.
- Resolve by appending `## Answer`, setting `Status: resolved`, and adding a concise pointer to the map's Decisions-so-far.

These planning operations precede harness execution and do not authorize changing
approved run inputs.
