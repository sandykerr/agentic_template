# Ownership and review scope

Apply this development contract when planning consequential mutable state,
implementing/repairing its operations, assigning Spec/Standards review or handing
work off. Follow [domain guidance](domain.md), ADRs and approved target contracts.
[Review records](review-records.md) own identities/dispositions;
[architecture checkpoints](architecture-checkpoints.md) own progression gates.
This guidance adds no runtime schema or gate.

## Planning and implementation

Record each consequential state contract in the spec's implementation decisions,
or link its authoritative contract:

| Decision | Required content |
| --- | --- |
| State and owner | State, responsible module and owned invariants. |
| Permitted writers | All authorized roles/modules, including initialization and recovery. |
| Operations | Invariant-preserving operations and ordering. |
| Persistence and restoration | Saved representation, reconstruction, shared identity/references and invalidation; explicitly state if nothing is durable. |
| Failures | Observable rejection/failure, partial transitions and outcome recorder. |

Describe responsibilities and operations; internal classes, methods and files
remain worker decisions. Before implementation, locate the approved contract and
map entry callers, owner operations, other writers, readers, save/restore and
invalidation. Implementation/repair evidence explains ownership changes and writer
migration, or why existing ownership remains correct. Prose work identifies the
guidance responsibility changed and whether executable ownership is unaffected.

Missing consequential ownership, incompatible writers, changed invariants or
scope expansion require a human decision with source, consequence and options.
Continue independent authorized work and routine choices within the approved
contract; a reviewer recommendation cannot authorize a new owner.

## Assign the whole ticket

Capture the original starting baseline and exact current committed source. Keep
that baseline fixed through repairs. Supply the full cumulative ticket diff,
approved behavior/ownership contracts, role settings/guidance, coverage/check
records and prior full finding keys/history, including pending revalidation and
human decisions. Use fresh separate Spec and Standards assignments with independently
configured settings. Each inspects source and saves its original report before
aggregation; exclude sibling reports from initial same-round assessment context.

- **Spec:** verify acceptance and approved behavior/ownership, including failures
  and compatibility; trace collaborators needed to establish the promised behavior.
- **Standards:** inspect definitions/usages and follow actual state/call flows
  beyond changed hunks: unchanged callers/consumers, every relevant writer,
  initialization, persistence/restoration and invalidation. Apply
  [codebase design](../../.agents/skills/matt-pocock/codebase-design/SKILL.md)
  and target standards to explain invariant coordination.

Scope follows affected responsibilities and concrete risks; a changed-file list
is only an inventory. Record omissions/reasons. Newly discovered out-of-scope
breaches stay visible for decision without authorizing neighboring refactors.
Existing repair bounds, required checks and milestone QA gates apply.

## Report substantive reasoning

Use the [report envelope](../templates/reviews/report.md) for exact baseline/source,
assignment/instruction identities, inspected flows (including unchanged
collaborators), omissions/reasons and unresolved assumptions. Distinguish:

1. **Substantive assessment:** connect approved contracts to actual operations,
   writers, callers and restored state; explain invariant preservation. A clean
   report explains why the inspected design is acceptable.
2. **Evidence audit:** commands, hashes, observations and limits. Hashes establish
   identity and passing tests observed behavior; neither proves a design conclusion.

Check explicit guarantees against accepted input values and reference aliases in
the supplied contract/implementation. Narrower assumptions require contract or
enforced validation support; disclosure alone cannot justify a clean result when
accepted inputs violate a guarantee. Give a concrete counterexample and classify
its consequence under the governing contract.

Findings cite exact code/contract locations, evidence, consequence, blocking versus
optional classification and proportionate remedy. An ownership breach in unchanged
code can block when it defeats the approved outcome. Class/function-length/layout
preferences alone cannot. A long cohesive function can be clean when callers cross
a small interface and its decisions require no external coordination; explain the
actual flow. Keep summaries concise, with detail linked; no universal report cap
may remove required scope/evidence/reasoning. Empty findings cover only inspected
scope. Apply [checkpoints](architecture-checkpoints.md) for broader required work.

## Repair and handoff

A fresh repair assignment receives the exact rejected source, original reports,
full review/report/local keys and disposition history, plus approved contracts.
Record changed/unchanged ownership, claimed fixes and checks. Independently verify
fixes at the exact repair revision, then obtain fresh separate whole-ticket axes
from the original baseline. Preserve originals and append verification/history
under the [record contract](review-records.md#immutable-reports-and-append-only-history).
Changed source needs relevant exact-source revalidation; historical clean reports
retain their original scope. Optional suggestions remain optional.

Handoffs link ownership/affected flows, assessment scope, original baseline/current
source, unresolved full keys, missing reports, pending revalidation and human
decisions, with explicit absences and the next responsible action. Preserve
active inputs, evidence, authorized scope and milestone boundaries. Assessment
completion and risk disposition remain separate from integration eligibility and
human QA acceptance.
