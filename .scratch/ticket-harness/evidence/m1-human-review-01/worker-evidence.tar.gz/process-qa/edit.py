from pathlib import Path
p=Path('ticket_harness/records.py')
s=p.read_text()
a=s.index('            try:\n                captured_out')
b=s.index('            out.write(captured_out)',a)
communication=s[a:b]
s=s[:a]+'''            captured_out, captured_err = _communicate(process, payload, timeout_seconds, stage, gate)
'''+s[b:]
a=s.index('                # Also stop background children')
b=s.index('    return gate',a)
cleanup=s[a:b]
s=s[:a]+'''                _finish_process(process, gate)
'''+s[b:]
# Keep bodies verbatim apart from their new indentation and returning captured output.
communication='\n'.join(line[8:] if line else line for line in communication.rstrip().splitlines())
cleanup='\n'.join(line[12:] if line else line for line in cleanup.rstrip().splitlines())
insert='''\n\ndef _communicate(
    process: subprocess.Popen[bytes],
    payload: str | None,
    timeout_seconds: int | float,
    stage: str,
    gate: dict[str, Any],
) -> tuple[bytes, bytes]:
    """Capture output by the deadline, killing the group and bounding its final drain.

    Timeout and cleanup failures update the shared gate; partial output is retained.
    """
'''+communication+'''\n    return captured_out, captured_err


def _finish_process(process: subprocess.Popen[bytes], gate: dict[str, Any]) -> None:
    """Stop remaining group members, bound leader reaping, and close every pipe.

    Called from execution's finally block even after normal completion; records the
    final exit code and any failure to reap after SIGKILL.
    """
'''+cleanup+'\n'
s=s.replace('\n\ndef stop_group(',insert+'\n\ndef stop_group(')
s=s.replace('    temporary = path.with_suffix', '    """Replace a JSON record via a sibling temporary file; propagate filesystem errors."""\n    temporary = path.with_suffix',1)
s=s.replace('    """Bracket external execution; True paths are restored, False paths stay inspectable."""','''    """Snapshot protected paths and existing artifacts around external execution.

    On every exit, preserve observed violations and mark evidence failed. Restore
    prior bytes for True paths (including existing artifacts); False paths remain
    inspectable. Restoration errors propagate rather than claiming intact evidence.
    """''')
s=s.replace('    artifact_name = artifact_name or stage','''    """Run one command in a new session and return its gate with captured artifacts.

    Assignments are persisted and sent as JSON stdin. Deadlines kill the process
    group; final cleanup also removes background children after successful exits.
    Spawn/communication OS errors become failed evidence, and integrity checks run
    after process cleanup before the gate is returned.
    """
    artifact_name = artifact_name or stage''',1)
p.write_text(s)
p=Path('ticket_harness/qa.py'); s=p.read_text()
a=s.index('    def _prepare('); b=s.index('    def _await_decision',a)
old=s[a:b]
fresh=old[old.index('            self._milestone.update'):old.index('        else:')]
restored=old[old.index('            request_path =',old.index('        else:')):]
fresh='\n'.join(line[4:] if line else line for line in fresh.rstrip().splitlines())+'\n'
restored='\n'.join(line[4:] if line else line for line in restored.rstrip().splitlines())+'\n'
publish=fresh.index('        self._request = {')
create=fresh[:publish]
# Separate candidate creation/checks from publishing the exact approved-input request.
replacement='''    def _prepare(self, checkpoint: dict[str, Any] | None) -> None:
        """Prepare a fresh candidate or reopen the same frozen request without replay.

        Preparation never advances refs or spends a ticket repair attempt.
        """
        self._verification.stage = "milestone-candidate"
        require_direct_branches(self._repository, self._integration, self._development)
        if checkpoint is None:
            regression = self._verify_candidate()
            self._publish_request(regression)
        else:
            self._restore_request(checkpoint)

    def _verify_candidate(self) -> dict[str, Any]:
        """Merge and regress the candidate, then reject changed inputs or branch tips.

        Save preparation state before Git work; merge failures require renewed
        verification rather than entering ticket repair.
        """
'''+create+'''        return regression

    def _publish_request(self, regression: dict[str, Any]) -> None:
        """Publish the exact QA request and freeze evidence before saving the wait state."""
'''+fresh[publish:]+'''
    def _restore_request(self, checkpoint: dict[str, Any]) -> None:
        """Reopen a validated request and add its archive identity to frozen evidence.

        Reuse the existing candidate and regression evidence; only the run's wait
        state is saved, with no candidate creation or check replay.
        """
'''+restored+'\n'
s=s[:a]+replacement+s[b:]
a=s.index('        expected_record = dict(record)',s.index('    def restore_checkpoint'))
b=s.index('        inputs.require_approved(record["inputs"])',a)
identity=s[a:b]
s=s[:a]+'''        MilestoneReview._require_checkpoint_identity(output, record, checkpoint)
'''+s[b:]
s+='''
    @staticmethod
    def _require_checkpoint_identity(
        output: Path, record: dict[str, Any], checkpoint: dict[str, Any]
    ) -> None:
        """Reject a different checkpoint schema, run record, directory, or archive.

        The live record alone carries checkpoint_sha256; exclude only that field
        when comparing it with the record embedded before the checkpoint was hashed.
        """
'''+identity
p.write_text(s)
