import ast
from pathlib import Path

docs={
'qa.py':{
'_digest':'Hash regular evidence bytes; reject missing, nonregular, or symbolic paths.',
'ownership':'Exclusively lock the run directory inode until context exit.\n\n    Reject another active owner without waiting; always close the lock descriptor.',
'stop':'Request a deliberate stop from the active QA owner for its exact request.\n\n    Reject inactive or nonwaiting runs; the owner validates and persists the stop.',
'_evidence_files':'List current artifacts and checkpoint archives whose identities must be frozen.',
'__init__':'Bind the run-owned record and verification operations for one milestone.\n\n        Keep the shared milestone identity; request and evidence state belongs to\n        this review until promotion or a deliberate checkpoint stop.',
'execute':'Prepare or restore the request, then wait for a stop or exact human approval.',
'_await_decision':'Poll for a clean stop or changed decision bytes until promotion succeeds.\n\n        Invalid decisions remain observations and do not authorize repairs or refs.',
'_stop_if_requested':'Consume a matching stop request only after revalidating frozen inputs.\n\n        Discard stale requests; persist current observations in a deliberate checkpoint.',
'_read_decision':'Read regular decision bytes, saving missing/unreadable status transitions.\n\n        Reset the observed identity on read failure so a restored file is reconsidered.',
'_consider_decision':'Archive decision bytes and promote only an unconsumed exact approval.\n\n        Rejections are saved and leave the wait active. Accepted input is revalidated\n        before the atomic ref transaction; consumption is recorded after it succeeds.',
'_require_current':'Reject stale approvals, verified sources, request bytes, or evidence.\n\n        A deliberate stop also validates destination refs before checkpoint creation.',
'_persist':'Write and archive a version-1 deliberate checkpoint, then save its digest.\n\n        Export run-owned canonical checks without changing their identity or ownership.',
'restore_checkpoint':'Validate a deliberate checkpoint and its frozen inputs before returning it.\n\n        Reject arbitrary interruption recovery, changed records/evidence/sources or\n        destination refs. Reconstruction of canonical checks remains run-owned.',
},
'git.py':{
'git':'Run Git in the target repository; return stripped stdout or raise GateFailure.',
'worktree':'Create a detached worktree at the revision and return its path.',
'require_unchanged':'Reject changed HEAD, worktree contents, or hidden index visibility flags.',
'capture':'Commit the submitted working tree without permitting worker-owned HEAD changes.\n\n    Stage all changes and return the submission revision with paths changed since\n    base (or start); an initial empty submission is rejected.',
'candidate':'Create a detached merge candidate; leave destination refs unchanged.\n\n    Merge failures propagate while the candidate remains available for diagnosis.',
'require_reviewed_candidate':'Reject a candidate whose parents or tree differ from the reviewed submission.\n\n    Also require its detached worktree to retain the verified revision unchanged.',
'promote':'Advance the integration ref only while its expected identity remains current.\n\n    If provided, lock and verify the development ref at its current tip in the same\n    transaction; destination names must remain direct branches.',
}}
for name, mapping in docs.items():
    p=Path('ticket_harness')/name
    s=p.read_text(); lines=s.splitlines(keepends=True); additions=[]
    for node in ast.walk(ast.parse(s)):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in mapping and ast.get_docstring(node) is None:
            first=node.body[0]
            indent=' '*(node.col_offset+4)
            additions.append((first.lineno-1,indent+'"""'+mapping[node.name]+'"""\n'))
    for i,value in sorted(additions,reverse=True): lines.insert(i,value)
    p.write_text(''.join(lines))
p=Path('ticket_harness/qa.py'); s=p.read_text()
s=s.replace('    def save(self) -> None: ...','''    def save(self) -> None:
        """Persist the shared run record after a review-owned state transition."""
        ...''')
s=s.replace('    def git_operation(self, name: str) -> AbstractContextManager[None]: ...','''    def git_operation(self, name: str) -> AbstractContextManager[None]:
        """Bracket a named Git operation with the run's protected-input checks."""
        ...''')
s=s.replace('    def check(self, stage: str, argv: list[str], source: Path, revision: str) -> dict[str, Any]: ...','''    def check(self, stage: str, argv: list[str], source: Path, revision: str) -> dict[str, Any]:
        """Run and register an exact-source gate, rejecting failure through run policy."""
        ...''')
s=s.replace('    def validate_sources(self) -> None: ...','''    def validate_sources(self) -> None:
        """Invalidate canonical run checks whose source identity no longer holds."""
        ...''')
s=s.replace('    def export_checks(self) -> list[list[Any]]: ...','''    def export_checks(self) -> list[list[Any]]:
        """Serialize canonical verified checks for the deliberate checkpoint."""
        ...''')
p.write_text(s)
