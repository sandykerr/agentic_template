# Readability correction: process and milestone review

Scope: records.py/qa.py executable readability and docstrings; git.py docstrings only. Fixed baseline HEAD d02e61ea27de4febd17e337bd51529d07861226b; exact pre-edit files /tmp/m1-human-review-20261112/before. Retained owned source hashes and copies alongside this report. Existing dirty documentation/trackers/QA files were not edited. Root owns final cumulative source review/checks and bookkeeping.

## Existing ownership and contracts

Read AGENTS/domain glossary, ADR-0001/0002, docs/agents/{python-environment,testing,ownership-review,architecture-checkpoints}.md; codebase-design/test-strategy/TDD skills; spec ownership/refactor verification and ticket24 acceptance. No new behavior or test seam is needed for this mechanical refactor.

Process entry callers remain runner.check and runner.git_operation: run owns gates, protected-path policy and interpretation, records owns external session execution and integrity observations. protect copies restoration policy, snapshots existing artifacts, yields, then captures observed violations before restoring prior bytes and marking shared evidence failed. The visible single finally loop retains this ordering and exception propagation. Splitting protect would disperse the tightly coupled archive/restoration logic; retained it and clarified the contract.

execute retains Popen creation and OS-error handling inside protect and output-file contexts. _communicate owns initial deadline, whole-group termination and bounded five-second output drain, with partial bytes retained. _finish_process stays in finally: kill remaining group members, bounded five-second reap, close streams, record final returncode. Command arrays, session flag, env injection, gate/cleanup shapes and timeout values are unchanged.

MilestoneReview still holds one shared record/milestone identity, candidate revisions, request, evidence and observations across fresh/restored preparation. _verify_candidate performs saved preparation, protected merge, protected clean-tree validation, regression, readiness checks and expected-tip validation. _publish_request publishes both copies, records wait state, freezes content identities, saves. _restore_request reloads the previously validated request/candidate and checkpoint evidence, freezes the current archive, saves wait state. Existing _await_decision, stop, decision validation, promotion and persistence remain in the same owner.

restore_checkpoint still validates deliberate-stop state and checkpoint digest before parsing; _require_checkpoint_identity groups version/directory/embedded record and archive identity checks. Then restore_checkpoint validates approved inputs, request/evidence bytes, verified source revisions and destination refs in the same order. The checkpoint schema/version and original record comparison (exclude only live checkpoint_sha256) remain unchanged. runner._Run.restore_checks remains the only canonical check-reference rebinding operation; no list copying or new writer was introduced. Promotion's prepared ref transaction, decision consumption after successful promotion, and directory inode ownership lock are unchanged.

## Four ownership triggers

All start/post values are No, relative to the requested correction at d02e61e:

- New lifecycle: No/No. Existing records process lifetime and MilestoneReview preparation/wait/stop/promote lifetime remain; helpers name phases inside existing owners.
- New persistence/restoration path: No/No. write_json, protect, QA request/checkpoint/archive writing and continuation validation existed at baseline. Same shapes, fields, version and ordering; extracted validation does not add a path.
- New shared mutable state: No/No. Gate, shared run/milestone records, request/evidence and canonical restored checks remain owned and referenced as before. Helpers use existing state and locals; no new stored state.
- Additional writer: No/No. Module/class operations still perform their prior writes. New private helpers move existing statements under the same process/review owner; no caller gains mutation authority and Git executable statements are unchanged.

## Existing public CLI coverage map

- Fresh preparation/exact decisions/ref locking: two_foreground_milestones_require_exact_acceptance_and_consume_each_decision; approval_rejects_same_oid_alias_installed_after_destination_validation; acceptance_revalidates_the_exact_candidate_evidence_and_both_refs (existing parameter matrix).
- Deliberate stop/restoration/no replay/lineage: clean_qa_stop_continues_in_new_process_without_replaying_done_work; repeated_stops_retain_previous_decisions_and_checkpoint_lineage.
- Saved identities/ref/frozen-input rejection: continuation_rejects_changed_checkpoint_without_overwriting_prior_state (existing parameter matrix).
- Process deadline/session/children/output: worker_timeout_stops_children_preserves_output_and_blocks; exited_worker_with_child_holding_output_cannot_approve_or_request_decision (both variants).
- OS error/finalization: unavailable_shared_executable_stops_run_without_repairs.
- protect finally during timeout and immutable evidence restoration: timeout_cannot_hide_evidence_tampering_or_authorize_repair.

No additional test cases were required: the requested changes preserve behavior at existing approved CLI/process/real-Git seams. All new helpers are private implementation phases, not new test seams.

## Limits and unresolved work

Known OPEN cumulative blocker review-M1-architecture-01/standards-01/F1 (ambient GIT_INDEX_FILE can mutate caller index) remains unchanged and outside this readability correction. Git changes are docstrings only. This report neither fixes nor reclassifies that finding. Historical ticket24 completion is not milestone acceptance. No new QA candidate/request/approval was created. Genuine pre-refactor checkpoint compatibility is left to existing evidence/root final verification; this focused run does not claim a newly produced historical checkpoint. No full-suite/static-type completion claim: root owns final whole-source 559/static verification. Other workers' modules are outside this exclusive edit/assessment scope.

## Final focused check results

37 selected cases passed (32 deselected) in 125.54s; an additional canonical restored-check invalidation case passed in 5.10s. Both pytest commands exited 0. Scoped Ruff check and format-check exited 0 using Ruff 0.14.10; owned-file whitespace check passed. Owned source/test SHA-256 values matched the retained manifest after execution. All command lines/results/logs are adjacent in commands.txt, pytest.log, canonical-restoration.log, ruff-check.log, ruff-format.log and doc-only.log. No code changes occurred after these owned-source checks. Whole-source full suite/type/static verification remains the root's responsibility.
