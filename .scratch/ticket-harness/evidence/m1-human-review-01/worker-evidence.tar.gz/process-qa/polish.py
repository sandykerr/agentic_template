from pathlib import Path
for name in ('qa.py','git.py'):
    p=Path('ticket_harness')/name
    lines=p.read_text().splitlines(); result=[]; indent=None
    for line in lines:
        if indent is None:
            if line.count('"""') == 1:
                indent=line[:len(line)-len(line.lstrip())]
            result.append(line)
        elif '"""' in line:
            before=line.split('"""')[0]
            if before.strip():
                result.extend([before,indent+'"""'])
            else:
                result.append(line)
            indent=None
        else:
            result.append(line)
    p.write_text('\n'.join(result)+'\n')
