"""Static evidence: Git executable AST and protect body remain unchanged."""
import ast
from pathlib import Path
class StripDocs(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
            node.body.pop(0)
        return node
    visit_ClassDef = visit_FunctionDef

def source(path):
    return StripDocs().visit(ast.parse(path.read_text()))
base=Path('/tmp/m1-human-review-20261112/before')
assert ast.dump(source(base/'git.py')) == ast.dump(source(Path('ticket_harness/git.py')))
print('PASS: Git executable AST unchanged from pre-edit baseline')
before=next(n for n in source(base/'records.py').body if isinstance(n,ast.FunctionDef) and n.name=='protect')
after=next(n for n in source(Path('ticket_harness/records.py')).body if isinstance(n,ast.FunctionDef) and n.name=='protect')
assert ast.dump(before) == ast.dump(after)
print('PASS: protect executable AST unchanged from pre-edit baseline')
