import json
from pathlib import Path
import subprocess
import sys
out=Path('/tmp/m1-human-review-20261112/execution')
command=[sys.executable,'-m','pytest','-q','tests/test_repairs.py::test_valid_human_decision_stops_without_capture_or_repair']
with (out/'implementation-decision.log').open('w') as stream:
 result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
(out/'implementation-decision-result.json').write_text(json.dumps({'command':command,'exit_code':result.returncode},indent=2)+'\n')
print((out/'implementation-decision.log').read_text())
