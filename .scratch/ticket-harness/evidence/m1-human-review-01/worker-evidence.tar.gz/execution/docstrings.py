import ast
from pathlib import Path

notes = {
 'tickets.py': {
 '_Attempt.__init__': 'Register a Running attempt in history and reset its shared ticket projection.',
 '_Attempt.observe_source': 'Retain the implementation worktree on attempt evidence for rejection/repair.',
 '_Attempt.submit': 'Record Git-derived submission facts and expose them on the current ticket.',
 '_Attempt.observe_candidate': 'Attach the candidate revision to both attempt and current ticket evidence.',
 '_Attempt.complete': 'Mark attempt and ticket Done after integration; close the attempt gate range.',
 '_Attempt.reject': 'Close rejected attempt evidence while leaving terminal ticket policy to the run.',
 '_Attempt.attach_human_decision': 'Attach a validated decision to this attempt and ticket, rejecting mismatched identity.',
 '_completed': 'Combine externally completed prerequisites with this run\'s Done tickets.',
 'initialize': 'Create Pending ticket records, unlock prerequisites, and alias the active ticket.',
 'unlock': 'Move selected Pending tickets to Ready when every prerequisite is completed.',
 'next_ready': 'Select the next Ready ticket in milestone/numeric order, or reject stalled work.',
 '_TicketExecution.__init__': 'Bind a fixed-base ticket cycle to shared evidence and scoped verification.\n\nSelect its approved ticket snapshot without mutating the run snapshot mapping;\nattempt records and current-ticket observations retain their shared identity.',
 '_TicketExecution._ticket_gates': 'Select shared and current-ticket evidence without copying canonical gate records.',
 },
 'runner.py': {
 '_Run.__init__': 'Prepare run directories and bind a restored record, or create a fresh run record.',
 '_Run.save': 'Atomically replace run.json with the current canonical run observations.',
 '_Run.restore_checks': 'Rebind checkpoint verification references to canonical gates for later invalidation.',
 '_Run.reject_checks': 'Discard this ticket\'s verification authority, then validate retained shared sources.',
 '_Run.artifact_name': 'Derive collision-free evidence names for ticket attempts and later milestones.',
 '_Run.protected_paths': 'Map run evidence to restoration and approved originals/worktree copies to retention.',
 '_Run.git_operation': 'Persist a Git operation and bracket it with integrity protection.\n\nAlways save its final observations; integrity violations are nonrepairable even\nwhen the enclosed operation also fails.',
 '_Run.validate_sources': 'Invalidate canonical gates whose verified Git sources changed; save before raising.',
 '_Run.check': 'Run a required gate after validating approved inputs and earlier sources.\n\nPersist execution before report evaluation; register nonimplementation sources\nonly after report handling, then revalidate sources before accepting the gate.\nEnvironment/integrity failures and trusted human decisions prevent repair.',
 '_TicketVerification.__init__': 'Bind verification operations to one ticket without exposing runner-owned state.',
 '_TicketVerification.observe': 'Persist the current ticket stage through the owning run.',
 '_TicketVerification.operation': 'Yield this attempt\'s worktree path inside the run-owned protected Git operation.',
 '_TicketVerification.check': 'Run and record this ticket\'s gate; propagate the runner\'s failure classification.',
 '_TicketVerification.validate_sources': 'Validate approved inputs and either current authority or retained repair evidence.',
 'run': 'Create a new output directory and execute with exclusive run ownership.',
 'continue_run': 'Restore and execute a deliberate QA checkpoint under exclusive ownership.\n\nPreserve rejection diagnostics separately and expose failed continuation as ValueError.',
 },
 'agents.py': {
 'assignment': 'Build fresh role guidance and captured inputs for one revision-bound assignment.\n\nSnapshot artifacts must be readable. Gate/check/repair values retain their supplied\nreferences; only the harness interprets returned agent claims as evidence.',
 'text_list': 'Reject values other than a list of nonblank strings; empty lists are allowed.',
 'implementation': 'Validate implementation claims and result-specific evidence, raising ValueError.',
 'review': 'Require complete findings with unique IDs and typed decision flags; allow no findings.',
 'report_object': 'Decode object pairs while rejecting duplicate keys at every JSON object level.',
 'invalid_constant': 'Reject JSON nonfinite constants rather than accepting decoder extensions.',
 'finite_number': 'Parse a JSON float and reject overflow to a nonfinite value.',
 'require_bounded_nesting': 'Reject object/array nesting beyond 100 levels without recursive traversal.',
 }
}
for filename, entries in notes.items():
 p=Path('ticket_harness')/filename
 source=p.read_text()
 tree=ast.parse(source)
 lines=source.splitlines(keepends=True)
 inserts=[]
 def walk(nodes, prefix=''):
  for n in nodes:
   if isinstance(n, ast.ClassDef): walk(n.body, n.name + '.')
   if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
    key=prefix+n.name
    if key not in entries: continue
    assert ast.get_docstring(n) is None, key
    indent=' '*(n.col_offset+4)
    doc=entries.pop(key)
    rendered=indent+'"""'+doc.replace('\n', '\n'+indent)+'"""\n'
    inserts.append((n.body[0].lineno-1,rendered))
 walk(tree.body)
 assert not entries, entries
 for index, value in sorted(inserts, reverse=True): lines.insert(index,value)
 p.write_text(''.join(lines))
