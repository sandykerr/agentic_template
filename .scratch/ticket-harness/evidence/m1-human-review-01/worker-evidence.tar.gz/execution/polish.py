from pathlib import Path
for filename in ('tickets.py', 'runner.py', 'agents.py'):
 p=Path('ticket_harness')/filename
 s=p.read_text()
 # Put docstrings before implementation comments and close multiline descriptions on their own line.
 import re
 s=re.sub(r'(    +)(#[^\n]*\n)(    +)("""[^\n]*"""\n)', lambda m: m[3]+m[4]+m[1]+m[2], s)
 s=s.replace('shared identity."""', 'shared identity.\n        """')
 s=s.replace('also fails."""', 'also fails.\n        """')
 s=s.replace('prevent repair."""', 'prevent repair.\n        """')
 s=s.replace('as ValueError."""', 'as ValueError.\n    """')
 s=s.replace('claims as evidence."""', 'claims as evidence.\n    """')
 if filename=='tickets.py':
  s=s.replace('"""Return the tested candidate only after expected-old integration succeeds."""', '''"""Run bounded attempts through submission, checks, reviews and candidate testing.

        Return the tested revision only after expected-old integration succeeds.
        Reject failed attempts before deciding whether preserved work may be repaired;
        nonrepairable failures, integration failures and exhaustion propagate.
        """''')
 if filename=='runner.py':
  s=s.replace('"""Start from prepared inputs or continue the validated deliberate checkpoint."""', '''"""Execute eligible tickets and milestone QA from fresh inputs or a checkpoint.

        The caller must hold run ownership. Save canonical outcomes on success,
        deliberate QA stop, or handled failure; return the record and CLI exit code.
        Continuation uses restored verification authority before admitting more work.
        """''')
 if filename=='agents.py':
  s=s.replace('"""Return parsed content and validation observations without editing a gate."""', '''"""Return parsed content and validation observations without editing a gate.

    Require exact assignment identities and complete role-specific fields. Invalid
    JSON/schema content returns a failed observation; unreadable stdout propagates
    its filesystem error. A valid report alone does not establish gate success.
    """''')
 p.write_text(s)
