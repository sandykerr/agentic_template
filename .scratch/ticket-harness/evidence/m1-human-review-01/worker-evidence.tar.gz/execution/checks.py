import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

out=Path('/tmp/m1-human-review-20261112/execution')
paths=[*Path('ticket_harness').glob('*.py'),*Path('tests').glob('*.py')]
identity={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(out/'tested-source.json').write_text(json.dumps(identity,indent=2)+'\n')
commands=[
 [sys.executable,'-m','pytest','-q',
 'tests/test_repairs.py::test_failed_check_repairs_current_changes_and_renews_all_gates',
 'tests/test_repairs.py::test_invalid_worker_report_preserves_uncommitted_changes_for_fresh_repair',
 'tests/test_repairs.py::test_external_integration_change_after_rejection_does_not_authorize_repair',
 'tests/test_repairs.py::test_repair_source_mutation_invalidates_approval_before_another_full_verification',
 'tests/test_reports.py::test_incomplete_implementation_evidence_cannot_submit',
 'tests/test_reports.py::test_nonzero_exit_rejects_even_complete_success_report',
 'tests/test_reports.py::test_complete_optional_finding_is_accepted_and_preserved',
 'tests/test_reports.py::test_complete_blocker_is_valid_but_prevents_integration',
 'tests/test_human_decisions.py::test_decision_takes_precedence_over_repairable_findings_in_same_review',
 'tests/test_human_decisions.py::test_optional_decision_flag_preserves_ordinary_nonblocking_behavior',
 'tests/test_timeouts.py::test_exited_worker_with_child_holding_output_cannot_approve_or_request_decision',
 'tests/test_timeouts.py::test_unavailable_shared_executable_stops_run_without_repairs'],
 [sys.executable,'-m','ruff','check','ticket_harness/tickets.py','ticket_harness/runner.py','ticket_harness/agents.py'],
 [sys.executable,'-m','ruff','format','--check','ticket_harness/tickets.py','ticket_harness/runner.py','ticket_harness/agents.py'],
 ['git','diff','--check','--','ticket_harness/tickets.py','ticket_harness/runner.py','ticket_harness/agents.py'],
]
env=dict(os.environ,PYTHONPATH='/tmp/ticket23-tools',TICKET_HARNESS_TEST_OBSERVATIONS=str(out/'observations'))
results=[]
for index, command in enumerate(commands):
 log=out/f'check-{index}.log'
 with log.open('w') as stream:
  process=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
 result={'command':command,'exit_code':process.returncode,'log':str(log)}
 results.append(result)
 (out/'check-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(result),flush=True)
 print(log.read_text()[-1500:],flush=True)
