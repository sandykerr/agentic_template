# Execution worker handoff

Scope: only ticket_harness/tickets.py, runner.py, agents.py changed. Fixed cumulative package baseline supplied by root: d02e61e; actual pre-edit files supplied at /tmp/m1-human-review-20261112/before. Exact tested working-source SHA-256 values (including tests) are in tested-source.json. This worker did not modify tracker, QA records, tests, or unrelated existing dirty files.

Applied AGENTS.md, domain/glossary/ADR guidance, ownership-review, approved spec State and decision ownership, codebase-design, testing policy/test-strategy and TDD reference. This is an extraction preserving behavior, so existing public CLI regression coverage is reused rather than adding private helper tests.

## Start and post-change triggers

Each trigger is No at start and No after implementation:

- New lifecycle: No. _TicketExecution.execute retains initial/bounded attempt loop and visible stage assignments, while _implement and _prepare_repair contain existing ordered phases. _Attempt remains the only attempt observation operation owner; run outcome/Blocked classification remains _Run.execute.
- New persistence/restoration path: No. _Run.save/export_checks/restore_checks are unchanged except docstrings. Checkpoint version/shape and canonical gate rebinding are untouched; QA _persist still calls export_checks and continuation execute calls restore_checks.
- New shared mutable state: No. No fields added. _evaluate_report mutates the same canonical gate passed from check; decision report/input references retain identity. _report_contract constructs fresh dictionaries/lists for each assignment as the former inline literal did, while gate/check/repair references remain supplied aliases.
- Additional writer: No. Command/report gate handling stays _Run-owned; decision attachment still crosses only _Attempt.attach_human_decision. Ticket source/submission/repair operations stay in _TicketExecution. No new owner, checker object, factory module, registry or external mutation interface.

## Extraction and assessment

_TicketExecution.execute exposes stage assignment, ordered checks, reviews, candidate testing, integration, rejection and repair eligibility. _implement contains cohesive worktree/carry/capture/approved-path handling. It retains the implementation stage and every observation/save position. _prepare_repair contains rejected-verification invalidation, branch/HEAD refusal and repair-context preparation, preserving fixed base and original exception chaining.

_Run.check preserves input/source preflight, command execution, canonical gate append/save, environment failure, timed-out report refusal, report evaluation, nonimplementation source registration, source revalidation, and final gate rejection. _evaluate_report owns the former contiguous report block, including classification on exceptions after a human decision, and does not register verified sources. Every prior save stays in the same phase.

agents.assignment's nested contract literal moved to _report_contract in the same module. This names a meaningful payload responsibility without hiding actual fields across modules. Enum conversion would add no value: these are wire strings and guidance, not a new set of runtime states. A fresh builder preserves nested mutability/identity behavior; constants shared across assignments would not. Payload role-specific content, keys/types/defaults and key evaluation order are preserved.

Docstrings describe state mutations, expected inputs, return values and failure/order constraints where relevant. Small observation methods have concise mutation descriptions.

Inspected definitions/usages: all three scoped modules; runner ticket construction, _TicketVerification operations, run start/continuation; records GateFailure/NonRepairableFailure, execute/protect/write_json; git carry_changes/require_unchanged/capture/candidate/require_reviewed_candidate/promote; QA export protocol, _require_current/_persist and restore/continuation callers. No neighbors changed. This is an affected-flow assessment, not the cumulative package architecture review owned by root.

## Coverage map and checks

Existing CLI tests verify repair carry-forward and renewed gates, malformed implementation report preserving uncommitted work, external integration refusal, source mutation invalidation, incomplete reports, valid report plus nonzero process exit for all roles, optional/blocking findings, human-decision precedence in reviews, optional decision flag behavior, child-pipe timeout report refusal, and unavailable-executable stop. 19 passed in 32.93 seconds; exact selection, command and logs are check-results.json/check-0.log. A separate two-case implementation-decision check verifies both zero/nonzero exit stop without capture/repair; results are implementation-decision-result.json and implementation-decision.log.

Scoped Ruff lint and format checks passed, as did scoped git diff --check. The shared dev Python lacks Ruff; checks use existing /tmp/ticket23-tools through PYTHONPATH, without dependency installation. The initial absent-module formatter invocation was corrected before final source/check capture.

No tests were added or changed. Full suite/type checks are root-owned final-source gates and were not duplicated by this worker. Existing timeout/gate/repair matrices remain for that full suite.

## Unresolved scope and risks

review-M1-architecture-01/standards-01/F1 (ambient GIT_INDEX_FILE) remains OPEN and untouched. These readability changes do not establish milestone acceptance, resolve the original ticket24 tracking state, authorize promotion, or claim a new cumulative clean review. Remaining material risk is behavior-preservation across uncommon failure interactions; root's whole-source review/full suite remains required. Report helper adds a private exception-handling frame to preserve nonrepairability when decision attachment/persistence fails; serialized diagnostics and outward failure classes are preserved.
