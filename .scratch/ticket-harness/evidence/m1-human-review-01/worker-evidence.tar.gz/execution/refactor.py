from pathlib import Path

p = Path('ticket_harness/tickets.py')
s = p.read_text()
start = s.index('                self._verification.observe(stage)\n', s.index('    def execute(self) -> str:'))
end = s.index('                for name, argv in self._checks.items():', start)
block = s[start:end]
# Keep rejection-stage bookkeeping in execute; the implementation phase owns preparation/capture.
s = s[:start] + '                source, submitted = self._implement(attempt, current)\n' + s[end:]
block = block.replace('stage', '"implementation"')
# Supply the same terminal submission check and observation before returning.
helper = '\n    def _implement(self, attempt: int, current: _Attempt) -> tuple[Path, str]:\n        """Prepare preserved work, run implementation and capture its submission.\n\n        Register source/submission observations before validating approved paths,\n        so rejected work remains available to the existing repair policy.\n        """\n'
helper += '\n'.join(line[8:] for line in block.rstrip().splitlines()) + '\n        return source, submitted\n'
s += helper
start = s.index('                self._verification.validate_sources(rejected=True)')
end = s.index('        raise AssertionError', start)
block = s[start:end]
s = s[:start] + '                self._prepare_repair(current, error)\n' + s[end:]
s += '\n    def _prepare_repair(self, current: _Attempt, error: Exception) -> None:\n        """Invalidate rejected approvals and retain the next repair starting point.\n\n        Refuse repair if integration or the preserved implementation HEAD moved;\n        leave prior attempts and gate evidence intact for the next assignment.\n        """\n' + '\n'.join(line[8:] for line in block.rstrip().splitlines()) + '\n'
p.write_text(s)

p = Path('ticket_harness/agents.py')
s = p.read_text()
start = s.index('        "report_contract": {')
end = s.index('\n\n\ndef text_list', start)
block = s[start:end]
# The contract is a fresh JSON-shaped value each time, as before.
contract = block[len('        "report_contract": '):]
contract = contract[:contract.rfind(',\n    }')]
contract = '\n'.join(line[8:] if i else line for i, line in enumerate(contract.splitlines()))
s = s[:start] + '        "report_contract": _report_contract(role),\n    }\n\n\ndef _report_contract(role: str) -> dict[str, Any]:\n    """Build fresh report guidance for an implementation or review assignment.\n\n    Keep wire field names/types and role-specific required fields together; no\n    caller shares mutable contract dictionaries with another assignment.\n    """\n    return ' + contract + s[end:]
p.write_text(s)

p = Path('ticket_harness/runner.py')
s = p.read_text()
start = s.index('                observation = agents.report(')
end = s.index('            if stage != "implementation":', start)
block = s[start:end]
s = s[:start] + '                repairable = self._evaluate_report(\n                    result, prompt, stage, attempt, revision, owner, repairable\n                )\n' + s[end:]
helper = '''    def _evaluate_report(
        self,
        result: dict[str, Any],
        prompt: dict[str, Any],
        stage: str,
        attempt: int,
        revision: str,
        owner: tickets._Attempt | None,
        repairable: bool,
    ) -> bool:
        """Validate a completed report and save its gate/decision observations.

        Process failure still rejects a valid report; blocking human decisions
        attach to their owning attempt and make subsequent failures nonrepairable.
        Return the updated repair classification without registering verification.
        """
        try:
'''
helper += '\n'.join(line[4:] for line in block.rstrip().splitlines()) + '''
        except (GateFailure, OSError, ValueError, KeyError, TypeError) as error:
            if not repairable:
                raise NonRepairableFailure(str(error)) from error
            raise
        return repairable

'''
idx=s.index('\n\nclass _TicketVerification:')
s=s[:idx]+'\n\n'+helper.rstrip()+s[idx:]
p.write_text(s)
