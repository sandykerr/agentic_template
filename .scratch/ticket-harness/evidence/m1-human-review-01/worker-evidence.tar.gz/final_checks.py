from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time
root=Path.cwd(); out=root/'.scratch/ticket-harness/evidence/m1-human-review-01'
raw=Path('/tmp/m1-human-review-20261112/suite-observations')
source_paths=sorted([*root.glob('ticket_harness/*.py'),*root.glob('tests/*.py'),*root.glob('examples/**/*.py'),root/'pyproject.toml',root/'environment.yml'])
def hashes(): return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
source=hashes()
(out/'final-source.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'actual_source':'working tree with source patch and per-file identities; not represented as unchanged HEAD','sha256':source,'python':sys.version,'environment':{'PYTHONPATH':'/tmp/ticket23-tools','TICKET_HARNESS_TEST_OBSERVATIONS':str(raw)}},indent=2)+'\n')
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','ticket_harness']))
with tarfile.open(out/'final-source.tar.gz','x:gz') as archive:
    for path in source_paths:
        archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
command=[sys.executable,'-m','pytest','-q','--durations=20','--junitxml='+str(out/'pytest.xml')]
started=time.monotonic()
env=dict(os.environ,PYTHONPATH='/tmp/ticket23-tools',TICKET_HARNESS_TEST_OBSERVATIONS=str(raw))
(out/'full-suite-start.json').write_text(json.dumps({'command':command,'source':'final-source.json','log':'pytest.log'},indent=2)+'\n')
with (out/'pytest.log').open('w') as log:
    result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
unchanged=hashes()==source
record={'command':command,'exit':result.returncode,'seconds':time.monotonic()-started,'source':'final-source.json','source_unchanged_during_run':unchanged,'log':'pytest.log','junit':'pytest.xml'}
(out/'full-suite-result.json').write_text(json.dumps(record,indent=2)+'\n')
if raw.exists():
    with tarfile.open(out/'suite-observations.tar.gz','x:gz') as archive:
        archive.add(raw,arcname='observations')
    count=sum(p.is_file() for p in raw.rglob('*'))
    record.update(observation_files=count,archive='suite-observations.tar.gz',archive_sha256=hashlib.sha256((out/'suite-observations.tar.gz').read_bytes()).hexdigest())
    (out/'full-suite-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
assert unchanged,'Source/test bytes changed during verification'
sys.exit(result.returncode)
