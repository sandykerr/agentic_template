import ast
from pathlib import Path
for filename in ('inputs.py','plans.py','__main__.py'):
    p=Path('ticket_harness')/filename
    lines=p.read_text().splitlines(keepends=True)
    edits=[]
    for node in ast.walk(ast.parse(''.join(lines))):
        if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.Module)) and node.body:
            doc=node.body[0]
            if isinstance(doc, ast.Expr) and isinstance(doc.value, ast.Constant) and isinstance(doc.value.value,str) and doc.end_lineno>doc.lineno:
                index=doc.end_lineno-1
                if lines[index].strip()!='"""':
                    edits.append((index,lines[index].rstrip().removesuffix('"""')+'\n'+' '*doc.col_offset+'"""\n'))
    for index,line in sorted(edits,reverse=True): lines[index]=line
    p.write_text(''.join(lines))
