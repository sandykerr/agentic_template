from pathlib import Path
p=Path('ticket_harness/inputs.py'); s=p.read_text()
start=s.index('    for ticket_id in executable:',s.index('def load(')); end=s.index('    return PreparedInputs(',start)
body=s[start:end]
h='''def _require_executable(
    requirements: dict[str, Any], executable: list[str], completed: set[str]
) -> None:
    """Require agent readiness and satisfied prerequisites for every executable ID.

    Read prepared values without mutation. A plan supplies all required tickets,
    including later milestones; legacy runs supply only their selected tickets.
    Raise GateFailure on the first readiness or missing-prerequisite failure.
    """
'''+body+'\n\n'
s=s[:start]+'    _require_executable(requirements, executable, completed)\n'+s[end:]
s=s.replace('def load(',h+'def load(',1)
p.write_text(s)
for name in ('inputs.py','plans.py','__main__.py'):
    p=Path('ticket_harness')/name
    p.write_text(''.join(line.rstrip()+'\n' for line in p.read_text().splitlines()))
