from pathlib import Path
import ast

def document(path, docs):
    p=Path(path); s=p.read_text(); lines=s.splitlines(keepends=True)
    changes=[]
    for node in ast.walk(ast.parse(s)):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in docs:
            if ast.get_docstring(node):
                continue
            line=node.body[0].lineno-1
            indent=' '*(node.col_offset+4)
            doc=docs[node.name]
            changes.append((line, ''.join(indent+x+'\n' for x in ('"""'+doc+'"""').splitlines())))
    for line, text in sorted(changes,reverse=True): lines.insert(line,text)
    p.write_text(''.join(lines))

document('ticket_harness/inputs.py', {
 'timeouts': 'Return timeout defaults merged with validated stage seconds.\n\nReject unknown stages and nonpositive, nonfinite or oversized values with\nGateFailure; leave the supplied mapping unchanged.',
 'unique_object': 'Build one JSON object, rejecting duplicate keys with GateFailure.\n\nUsed as object_pairs_hook so duplicates cannot silently overwrite approval data.',
 'identifier': 'Normalize a positive numeric string to an ID padded to at least two digits.\n\nRaise GateFailure for invalid numeric text; preserve IDs wider than two digits.',
 'command': 'Validate argv and executable availability without launching the command.\n\nRelative executable paths must be executable blobs at base in repository;\nother commands must resolve absolutely on PATH. Raise GateFailure on rejection.',
 'configuration': 'Validate raw configuration and return that mapping with timeout/repair defaults.\n\nMutates defaults in place; executable and filesystem checks belong to load.\nRaise GateFailure on the first invalid field in contract validation order.',
 'normalize_ticket': 'Return normalized Markdown requirements and unresolved dependency references.\n\nIgnore examples/comments, then validate heading, metadata, dependencies and\nacceptance/check declarations in that order. Source text and checks remain\nunchanged; GateFailure identifies invalid or conflicting declarations. Graph\nconsistency and execution eligibility are checked later by load.',
 'validate_graph': 'Reject missing/mismatched references and cycles across the entire bundle.\n\nRead requirements and resolved link references without mutation. Validate\nreference identity before iterative cycle detection, raising GateFailure.',
 'completed_tickets': 'Return prerequisite IDs backed by captured completed runs integrated at base.\n\nRead saved records and current ticket bytes; validate approval hashes, Done\nrevisions and Git ancestry before accepting each ID. Evidence errors become\nsource-attributed GateFailure; JSON decoding and filesystem errors propagate.\nThe caller subsequently removes tickets that this run must verify again.',
 'require_approved': 'Recheck source and captured bytes against every recorded approval hash.\n\nRaise GateFailure on the first changed input; filesystem errors propagate.\nNeither the input records nor files are modified.',
 'execution_config': 'Return the existing JSON-safe execution/checkpoint mapping.\n\nCreate a new outer mapping without enriching raw settings. Nested prepared\nvalues retain their identities; this conversion does not copy or revalidate them.',
})
document('ticket_harness/plans.py', {
 'object_fields':'Require an object with exactly the declared fields; raise GateFailure on mismatch.',
 'text':'Require nonblank, NUL-free string content; raise field-attributed GateFailure.',
 'strings':'Validate a nonempty string array without mutation, raising GateFailure on failure.',
 'ticket_ids':'Return normalized IDs in declared order, rejecting invalid or duplicate membership.',
 'settings':'Validate a role profile or reason-bearing override without inserting defaults.\n\nRaise GateFailure for unsupported fields, invalid targets or empty overrides;\nrole default inheritance is applied later by plan validation.',
})
document('ticket_harness/__main__.py', {
 'main':'Dispatch run/status/stop/continue from process arguments and return an exit code.\n\nPrint the resulting record as JSON on stdout. Operational/input failures print\na diagnostic on stderr and return 1; argparse handles invalid CLI arguments.\nStatus reads existing state; other operations can write run or repository state.',
})
p=Path('ticket_harness/inputs.py'); s=p.read_text().replace('class Dependency:\n','class Dependency:\n    """Declared prerequisite identity plus optional title/link for later graph checks."""\n\n')
s=s.replace('    own fields. The execution mapping preserves', '    own fields. The frozen carrier retains mutable nested values; load alone\n    initializes them, and consumers must preserve their checked invariants.\n    The execution mapping preserves')
s=s.replace('    any worker/check execution or ref advancement. Source files are never written.\n', '    any worker/check execution or ref advancement. Source files are never written.\n    Return a complete PreparedInputs only after plan, graph, completion and\n    eligibility checks. GateFailure rejects invalid contracts; JSON/filesystem\n    errors propagate, and partial captures can remain if preparation fails.\n')
p.write_text(s)
