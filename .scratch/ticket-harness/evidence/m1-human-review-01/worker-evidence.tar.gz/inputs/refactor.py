from pathlib import Path
from textwrap import dedent
p=Path('ticket_harness/plans.py'); s=p.read_text()
start=s.index('    milestones = value["milestones"]', s.index('def validate(')); end=s.index('    if set(membership)', start)
body=s[start:end].replace('    milestones = value["milestones"]\n','',1)
helper='''def _milestone_membership(milestones: Any) -> dict[str, int]:
    """Validate QA groups, normalize ticket lists in place, and return their indexes.

    Raises GateFailure at the first malformed group or repeated membership.
    """
'''+body+'    return membership\n\n\n'
s=s[:start]+'    milestones = value["milestones"]\n    membership = _milestone_membership(milestones)\n'+s[end:]
start=s.index('    for ticket, index in membership.items():',s.index('def validate(')); end=s.index('    roles = value["roles"]',start)
body=s[start:end]
helper+='''def _validate_dependency_order(
    membership: dict[str, int], requirements: dict[str, Any]
) -> None:
    """Reject transitive prerequisites assigned after their dependent milestone.

    Traversal tolerates cycles here; input preparation separately rejects them.
    """
'''+body+'\n\n'
s=s[:start]+'    _validate_dependency_order(membership, requirements)\n'+s[end:]
start=s.index('    roles = value["roles"]',s.index('def validate(')); end=s.index('    for ticket, index in membership.items():',start)
body=s[start:end].replace('    workers = {','    return {')
helper+='''def _worker_settings(
    value: dict[str, Any], membership: dict[str, int], required: list[str]
) -> dict[str, Any]:
    """Normalize role defaults/overrides in place and return per-ticket profiles.

    Validate profiles in declaration order, raising GateFailure on invalid settings.
    """
'''+body+'\n\n'
s=s[:start]+'    workers = _worker_settings(value, membership, required)\n'+s[end:]
s=s.replace('def validate(',helper+'def validate(',1)
s=s.replace('    """Return normalized plan/settings; no candidate or QA acceptance is inferred."""','''    """Validate a plan against prepared tickets and return it with worker settings.

    Mutates membership, role defaults and overrides in the supplied plan. Checks
    run in contract order and raise GateFailure on the first conflict. Call before
    execution; the returned plan conveys no candidate or human QA acceptance.
    """''')
p.write_text(s)
p=Path('ticket_harness/inputs.py'); s=p.read_text()
# Extract dependency parsing and acceptance/check validation without changing order.
start=s.index('    declaration = metadata.get("Blocked by"'); end=s.index('    if len(re.findall(r"^## Acceptance criteria',start)
body=s[start:end].replace('    declaration = metadata.get("Blocked by", "")\n','',1)
h='''def _ticket_dependencies(declaration: str, path: Path) -> tuple[list[str], list[Dependency]]:
    """Parse Blocked by labels/links, retaining order and duplicate references.

    Resolve links relative to the ticket; reject malformed labels with GateFailure.
    """
'''+body+'    return dependencies, dependency_references\n\n\n'
s=s[:start]+'    dependencies, dependency_references = _ticket_dependencies(\n        metadata.get("Blocked by", ""), path\n    )\n'+s[end:]
start=s.index('    if len(re.findall(r"^## Acceptance criteria'); end=s.index('    plan_metadata = {',start)
body=s[start:end]
h+='''def _ticket_acceptance(
    text: str, metadata: dict[str, str], path: Path, checks: dict[str, Any]
) -> tuple[list[str], list[str]]:
    """Return checklist content and ordered check names, validating each declaration.

    Missing Checks metadata selects all configured checks. Raises GateFailure for
    malformed acceptance content or unknown/duplicate check references.
    """
'''+body+'    return requirements, references\n\n\n'
s=s[:start]+'    requirements, references = _ticket_acceptance(text, metadata, path, checks)\n'+s[end:]
s=s.replace('def normalize_ticket(',h+'def normalize_ticket(',1)
# Keep JSON decode outside the evidence error wrapper, preserve eager default eval.
start=s.index('            if not isinstance(record, dict):',s.index('def completed_tickets')); end=s.index('        except (KeyError',start)
body=dedent(s[start:end]); body=''.join('    '+line if line.strip() else line for line in body.splitlines(keepends=True))
h='''def _collect_completed(
    record: Any, requirements: dict[str, Any], repository: Path, base: str,
    completed: set[str],
) -> None:
    """Add evidence-backed Done IDs after checking approval hashes and ancestry.

    Mutates completed in record order, rejecting duplicates across records. Errors
    propagate to completed_tickets for source attribution; prior additions remain
    local to that preparation operation when a later entry fails.
    """
'''+body+'\n\n'
s=s[:start]+'            _collect_completed(record, requirements, repository, base, completed)\n'+s[end:]
s=s.replace('def completed_tickets(',h+'def completed_tickets(',1)
# Load phases remain ordinary private functions under load ownership.
start=s.index('    paths = {',s.index('def load(')); end=s.index('    snapshots: dict[str, Any] = {}',start)
body=s[start:end]
h='''def _input_paths(
    config: dict[str, Any], config_path: Path, repository: Path
) -> tuple[dict[str, Path], list[Path]]:
    """Resolve bundle/selection membership and name all approved input sources.

    Retain declaration order and artifact names; reject invalid selection before
    any snapshot is copied. Completed-run paths are relative to configuration.
    """
'''+body+'    return paths, selection\n\n\n'
s=s[:start]+'    paths, selection = _input_paths(config, config_path, repository)\n'+s[end:]
start=s.index('    snapshots: dict[str, Any] = {}',s.index('def load(')); end=s.index('    requirements: dict[str, Any] = {}',start)
body=s[start:end]
h+='''def _capture_inputs(paths: dict[str, Path], output: Path) -> dict[str, Any]:
    """Copy approved bytes to an existing inputs directory and return hash records.

    Reject source/output overlap before each copy. Filesystem errors propagate;
    earlier copies can remain when a later source fails. Never write source files.
    """
'''+body+'    return snapshots\n\n\n'
s=s[:start]+'    snapshots = _capture_inputs(paths, output)\n'+s[end:]
start=s.index('    requirements: dict[str, Any] = {}',s.index('def load(')); end=s.index('    checked_plan = None',start)
body=s[start:end].replace('                ticket = normalized','                primary = normalized["id"]')
h+='''def _ticket_requirements(
    snapshots: dict[str, Any], checks: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, list[Dependency]], str]:
    """Normalize captured ticket bytes and return requirements, links and primary ID.

    Requires the primary ticket snapshot. Reject duplicate normalized IDs before
    graph/plan validation; only newly created requirement mappings are populated.
    """
'''+body.replace('config["checks"]','checks')+'    return requirements, references, primary\n\n\n'
s=s[:start]+'    requirements, references, primary = _ticket_requirements(snapshots, config["checks"])\n'+s[end:]
# Replace references only in load tail, not other functions.
start=s.index('def load('); s=s[:start]+s[start:].replace('ticket["id"]','primary')
s=s.replace('def load(',h+'def load(',1)
p.write_text(s)
