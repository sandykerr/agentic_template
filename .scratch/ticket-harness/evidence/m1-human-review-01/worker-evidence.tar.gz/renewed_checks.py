from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,tarfile,time
root=Path.cwd(); out=root/'.scratch/ticket-harness/evidence/m1-human-review-01'
raw=Path('/tmp/m1-human-review-20261112/renewed-suite-observations')
source_paths=sorted([*root.glob('ticket_harness/*.py'),*root.glob('tests/*.py'),*root.glob('examples/**/*.py'),root/'pyproject.toml',root/'environment.yml'])
def hashes(): return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
source=hashes()
env=dict(os.environ,PYTHONPATH='/tmp/ticket23-tools:/tmp/m1-human-review-20261112',TICKET_HARNESS_TEST_OBSERVATIONS=str(raw),HUMAN_REVIEW_REPORTS=str(out/'renewed-reports.jsonl'))
(out/'renewed-source.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'actual_source':'uncommitted working tree identified by hashes, patch and archive','sha256':source,'python':sys.version,'capture_environment':{k:env[k] for k in ('PYTHONPATH','TICKET_HARNESS_TEST_OBSERVATIONS','HUMAN_REVIEW_REPORTS')}},indent=2)+'\n')
(out/'renewed-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','ticket_harness','tests']))
with tarfile.open(out/'renewed-source.tar.gz','x:gz') as tar:
    for p in source_paths: tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
commands=[[sys.executable,'-m','mypy'],[sys.executable,'-m','ruff','check','ticket_harness','tests','examples'],[sys.executable,'-m','ruff','format','--check','ticket_harness','tests','examples'],['git','diff','--check']]
results=[]
for i,command in enumerate(commands):
    started=time.monotonic()
    with (out/f'renewed-static-{i}.log').open('w') as stream:
        result=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
    results.append(dict(command=command,exit=result.returncode,seconds=time.monotonic()-started,source='renewed-source.json',log=f'renewed-static-{i}.log'))
    (out/'renewed-static-results.json').write_text(json.dumps(results,indent=2)+'\n')
    if result.returncode:
        print((out/f'renewed-static-{i}.log').read_text(),flush=True);sys.exit(result.returncode)
command=[sys.executable,'-m','pytest','-q','--durations=20','--maxfail=1','-p','human_review_capture','--junitxml='+str(out/'renewed-pytest.xml')]
started=time.monotonic();interrupted=False
with (out/'renewed-pytest.log').open('w') as log:
    process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'renewed-suite-start.json').write_text(json.dumps(dict(command=command,source='renewed-source.json',log='renewed-pytest.log',pid=process.pid),indent=2)+'\n')
    try: code=process.wait()
    except KeyboardInterrupt:
        interrupted=True;os.killpg(process.pid,signal.SIGINT)
        try: code=process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            process.kill();code=process.wait()
unchanged=hashes()==source
record=dict(command=command,exit=code,seconds=time.monotonic()-started,source='renewed-source.json',source_unchanged=unchanged,interrupted=interrupted,log='renewed-pytest.log',reports='renewed-reports.jsonl',junit='renewed-pytest.xml')
if raw.exists():
    with tarfile.open(out/'renewed-observations.tar.gz','x:gz') as tar: tar.add(raw,arcname='observations')
    record.update(observation_files=sum(p.is_file() for p in raw.rglob('*')),archive='renewed-observations.tar.gz',archive_sha256=hashlib.sha256((out/'renewed-observations.tar.gz').read_bytes()).hexdigest())
(out/'renewed-suite-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
assert unchanged,'Source changed during required verification'
sys.exit(code)
