"""Stream test-phase identities and failure traces before any interruption."""
import json
import os
from pathlib import Path


def pytest_runtest_logreport(report):
    record=dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome,duration=report.duration,longrepr=report.longreprtext if report.failed else None)
    with Path(os.environ['HUMAN_REVIEW_REPORTS']).open('a') as stream:
        stream.write(json.dumps(record)+'\n')
    if report.failed:
        print('\nRetained failure: '+report.nodeid+'\n'+report.longreprtext,flush=True)
