import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
root=Path.cwd()
out=Path('/tmp/m1-human-review-20261112/observer-diagnosis')
old=out/'before-runner'
old.mkdir(exist_ok=True)
for name in ('tests','examples'):
 shutil.copytree(root/name,old/name,dirs_exist_ok=True)
shutil.copy2(root/'pyproject.toml',old/'pyproject.toml')
shutil.copytree('/tmp/m1-human-review-20261112/before',old/'ticket_harness',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
node='tests/test_milestones.py::test_development_alias_after_validation_cannot_follow_automatic_integration'
results=[]
for label,work in [('current',root),('before',old)]:
 files=[*work.glob('ticket_harness/*.py'),*work.glob('tests/*.py'),*work.glob('examples/scripted/*'),work/'pyproject.toml']
 (out/f'{label}-source.json').write_text(json.dumps({str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()},indent=2)+'\n')
 command=[sys.executable,'-m','pytest','-vv',node]
 env=dict(os.environ,TICKET_HARNESS_TEST_OBSERVATIONS=str(out/f'{label}-observations'))
 with (out/f'{label}.log').open('w') as stream:
  result=subprocess.run(command,cwd=work,env=env,stdout=stream,stderr=subprocess.STDOUT)
 results.append(dict(command=command,cwd=str(work),exit_code=result.returncode,log=str(out/f'{label}.log')))
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 print((out/f'{label}.log').read_text()[-4500:],flush=True)
