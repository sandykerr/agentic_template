# Bounded automatic integration observer diagnosis

This diagnosis does not modify production or test files. Applicable diagnosing-bugs skill, Python environment/testing policy and domain/ownership guidance were read. Prior known scheduling issue: .scratch/ticket-harness/evidence/24-resume-diagnosis.md.

## Paired reproduction

`compare.py` invokes exactly the two parameterized automatic-integration alias scenarios with `pytest -vv` against current source, then against actual pre-edit package files copied from `/tmp/m1-human-review-20261112/before` into an isolated runner with identical existing tests, examples and pyproject.toml. It captures complete original logs, commands, cwd, exit values and source hashes. No passing result erases either failure.

- Current: 2 failed in 21.82s. False failed in observer stop handshake after seeking the read; True reached the body but ticket03 was Done rather than Verifying, before any alias mutation.
- Pre-edit: 1 failed, 1 passed in 21.25s. True exhausted observer deadline without finding the Git read. Same production protections remain in both versions.

`results.json`, `current.log`, `before.log`, `current-source.json`, `before-source.json` retain exact provenance. The process fixture's normal cleanup runs after failures; retained CLI/Git snapshots are under current-observations and before-observations.

## Ranked hypotheses and observations

1. Late observer entry: wait_for polls every25ms for a durable candidate gate that is only saved after the candidate suite finishes. Ticket integration immediately follows that save. The poll can therefore observe this permanently true predicate only after ticket03 integrated; the observer then matches ticket01's identical read. Current True's Done03 assertion and root's full-run record (ticket01 active,03Done) directly match the prediction.
2. Child sampling misses the narrow interval even if entry starts while03Verifying. pause_after_git resumes owner for1ms between actual-stop observations, so the owner can execute/reap a short Git read in that interval. Before True exhausting the deadline and current False's expired stop handshake are consistent with missing commands; existing observations do not independently distinguish initial late entry from a missed child in those two trials.
3. Extraction changes integration authority/order. This predicts a failure of actual alias/ref/locking outcomes only on current source. Instead current True fails before mutation and pre-edit also fails observer scheduling. Source comparison retains the same integration branch validation/ref transaction, with helper extraction only. These observations do not support a production authority regression.

## Proposed bounded observer repair

Use this test's configured external candidate-suite process as an explicit rendezvous. A wrapper runs the existing configured graph-check command; for TICKET_HARNESS_STAGE=candidate and the existing public fixture last-ticket file equal to03, publish a ready file and wait with a finite deadline for release. Before foreground launch, configure this wrapper through the normal suite command (no production/private helper hooks). Wait for ready rather than the post-suite durable gate. Then invoke pause_after_git with a trigger writing release: that helper confirms owner SIGSTOP before invoking its trigger, so the owner cannot complete candidate processing/integrate03 before observation is armed. The external script is in the fixture home outside target sources and output integrity evidence.

Retain the Verifying03 assertion and every mutation result, unchanged-ref, no-consumption, failure-stage, branch tip and post-abort lock-availability assertion. A missing observer match remains failure, never an inferred pass. No timeout increase, assertion weakening, Git mock or private production seam is needed.

This makes the demonstrated entry ordering deterministic; the helper's existing1ms process sampling still has a finite scheduling limitation. A claim of universally deterministic child interception would require a stronger process-event rendezvous (for example OS tracing), which is a broader fixture change and not justified as part of an unreviewed production repair. Root decides the proportionate test correction and validation scope. No additional full-suite run was started here.

## Authorized repair and retained trials

Root explicitly authorized correction of the same three existing public CLI scenarios after reviewing the original paired failure. No production file changed during this repair, no new test case was added, and the suite remains559 cases. tests/test_milestones.py owns the candidate rendezvous and shared observer/foreground options; tests/test_qa_promotion.py only opts its existing alias observer into trace recording.

- Unchanged-source three-case control:3 passed6.09s (`three-control.log`, matching source/result JSON). This finite pass coexists with original full-run and paired red observations.
- Candidate barrier + sleep(0) trial:1 failed/2 passed31.29s (`three-green-1.*`). False still missed the child even though candidate completion was held until arming.
- Immediate SIGCONT→SIGSTOP with no yield trial:3 failed66.00s (`three-handshake-1.*`), all actual-stop deadline failures. This unsuccessful attempt was retained and discarded, rather than retrying unchanged source for a favorable result.
- Root then authorized real Git Trace2 fallback for an actual unreaped direct Git child; original1ms sampling interval restored. Probe against installed Git2.53.0 records actual subprocess PID4 and SID `...-P00000004`, decoded base16 to4 (`git-trace2-pid-probe-result.json`). The raw installed-Git events are retained beside the probe.

Final observer reads actual /proc cmdline first. Empty cmdline permits fallback only when the currently listed direct child still exists and its comm is git; it selects that PID's latest real Trace2 start argv, never a historical trace entry without an actual child. Existing confirmed owner stop, matching command suffix, live transaction-open discrimination and eventual child zombie completion remain required. Trace output is enabled only for these three observer cases through optional foreground/helper paths; unrelated foreground commands inherit their environment as before. All authority/ref/lock/no-consumption assertions remain unchanged.

The candidate-suite wrapper first runs the existing configured check command and then publishes readiness only for the first candidate (public fixture last-ticket03). Its separate20s bound refuses an unreleased barrier. The test arms/confirms stopped owner before its trigger releases the external suite. These files stay in isolated fixture home and introduce no production state/persistence owner or private production seam.

Final-source results:

- `three-trace-1.log`:3 passed29.06s.
- `three-trace-2.log`:3 passed25.81s, identical source. A /tmp-only read-only pytest teardown plugin preserves the actual Trace2 files before fixture cleanup; its exact command and source identity are in the result/source JSON. This plugin changes no repository source or scenario behavior.
- `three-trace-3.log`:3 passed33.74s, identical source. All three source manifests compare equal and current source matches every recorded identity (`final-source.json`).

Scoped Ruff lint/format and git diff --check have exit0 with exact commands in `final-static-results.json`; final-static-*.log retain raw output. No full-suite campaign was replayed by this worker.

The rendezvous establishes first-candidate observation ordering. Trace2 restores otherwise lost completed-child identity while actual /proc ownership/completion remains decisive. Installed Git event encoding and Linux /proc/signal behavior are explicit fixture dependencies. Sampling may still fail under extreme scheduling; the bounded helper then fails instead of claiming an unobserved interleaving. These finite passes are not a universal flake-free guarantee. Root reviews final diff and owns the renewed559-case campaign and milestone readiness; ambient GIT_INDEX_FILE blocker remains outside this repair and open.
