from pathlib import Path
p=Path('tests/test_milestones.py')
s=p.read_text()
s=s.replace('def pause_after_git(process, arguments, *, transaction_open=False, trigger=None):','''def pause_after_git(
    process, arguments, *, transaction_open=False, trigger=None, git_trace=None
):''')
s=s.replace('''    owner before the foreground fixture performs its normal process cleanup.
''','''    owner before the foreground fixture performs its normal process cleanup.
    Optional real Git Trace2 events recover argv after a direct child becomes a
    zombie with empty cmdline; trace history alone never establishes a child.
''',1)
idx=s.index('    def suspend_owner():',s.index('def pause_after_git'))
s=s[:idx]+'''    def child_command(child):
        child_path = Path(f"/proc/{child}")
        command = (child_path / "cmdline").read_bytes().split(b"\\0")
        if command[0] or git_trace is None or (child_path / "comm").read_text().strip() != "git":
            return command
        if not git_trace.exists():
            return command
        # Git 2.53 Trace2's final SID component ends in -P<hex process PID>.
        # Keep the last start for this still-present child, never a reaped PID.
        for line in git_trace.read_text().splitlines():
            try:
                event = json.loads(line)
                pid = event.get("sid", "").rsplit("/", 1)[-1].rpartition("-P")[2]
                if event.get("event") == "start" and pid and int(pid, 16) == int(child):
                    command = [part.encode() for part in event["argv"]] + [b""]
            except (ValueError, KeyError):
                # A live Git child can still be appending its final trace line.
                continue
        return command

'''+s[idx:]
s=s.replace('command = Path(f"/proc/{child}/cmdline").read_bytes().split(b"\\0")','command = child_command(child)',1)
s=s.replace('Path(f"/proc/{pid}/cmdline").read_bytes().split(b"\\0")','child_command(pid)',1)
s=s.replace('''            # Yield immediately instead of leaving a millisecond in which the
            # owner could launch and reap the entire Git read between stops.
            time.sleep(0)
''','''            time.sleep(0.001)
''')
start=s.index('def test_development_alias_after_validation_cannot_follow_automatic_integration')
idx=s.index('    with foreground(graph) as process:',start)
s=s[:idx]+s[idx:].replace('    with foreground(graph) as process:','''    git_trace = graph.home / "observer-git.jsonl"
    with foreground(graph, git_trace=git_trace) as process:''',1)
idx=s.index('            transaction_open=after_prepare,',start)
s=s[:idx]+s[idx:].replace('''            transaction_open=after_prepare,
''','''            transaction_open=after_prepare,
            git_trace=git_trace,
''',1)
s=s.replace('def foreground(graph, operation="run"):', 'def foreground(graph, operation="run", *, git_trace=None):')
s=s.replace('''    with stdout_path.open("w") as stdout, stderr_path.open("w") as stderr:
        process = subprocess.Popen(
            command, stdout=stdout, stderr=stderr, text=True, start_new_session=True
        )
''','''    environment = None if git_trace is None else {**os.environ, "GIT_TRACE2_EVENT": str(git_trace)}
    with stdout_path.open("w") as stdout, stderr_path.open("w") as stderr:
        process = subprocess.Popen(
            command,
            stdout=stdout,
            stderr=stderr,
            text=True,
            start_new_session=True,
            env=environment,
        )
''')
p.write_text(s)
p=Path('tests/test_qa_promotion.py');s=p.read_text()
start=s.index('def test_approval_rejects_same_oid_alias_installed_after_destination_validation')
idx=s.index('    with foreground(graph) as process:',start)
s=s[:idx]+s[idx:].replace('    with foreground(graph) as process:', '''    git_trace = graph.home / "observer-git.jsonl"
    with foreground(graph, git_trace=git_trace) as process:''',1)
idx=s.index('            trigger=lambda: approve(graph, request),',start)
s=s[:idx]+s[idx:].replace('''            trigger=lambda: approve(graph, request),''','''            trigger=lambda: approve(graph, request),
            git_trace=git_trace,''',1)
p.write_text(s)
