import os
from pathlib import Path
import shutil
import pytest

@pytest.hookimpl(tryfirst=True)
def pytest_runtest_teardown(item, nextitem):
    graph=item.funcargs.get('graph')
    if graph is None:
        return
    trace=graph.home/'observer-git.jsonl'
    destination=Path(os.environ['TICKET_HARNESS_TEST_OBSERVATIONS'])
    if trace.exists():
        destination.mkdir(parents=True,exist_ok=True)
        shutil.copy2(trace,destination/(graph.home.name+'-git-trace2.jsonl'))
