import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd(); out=Path('/tmp/m1-human-review-20261112/observer-diagnosis')
label=sys.argv[1]
files=[*root.glob('ticket_harness/*.py'),*root.glob('tests/*.py'),*root.glob('examples/scripted/*')]
(out/f'{label}-source.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()},indent=2)+'\n')
command=[sys.executable,'-m','pytest','-vv','-p','trace_artifacts','tests/test_milestones.py::test_development_alias_after_validation_cannot_follow_automatic_integration','tests/test_qa_promotion.py::test_approval_rejects_same_oid_alias_installed_after_destination_validation']
with (out/f'{label}.log').open('w') as stream:
 result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONPATH=str(out),TICKET_HARNESS_TEST_OBSERVATIONS=str(out/f'{label}-observations')))
(out/f'{label}-result.json').write_text(json.dumps(dict(command=command,cwd=str(root),exit_code=result.returncode),indent=2)+'\n')
print((out/f'{label}.log').read_text()[-5500:])
