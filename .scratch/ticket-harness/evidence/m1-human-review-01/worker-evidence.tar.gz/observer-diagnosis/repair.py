from pathlib import Path
p=Path('tests/test_milestones.py')
s=p.read_text()
s=s.replace('''            paused = False
            time.sleep(0.001)
            if process.poll() is None:
''','''            paused = False
            # Yield immediately instead of leaving a millisecond in which the
            # owner could launch and reap the entire Git read between stops.
            time.sleep(0)
            if process.poll() is None:
''')
start=s.index('    configure_plan(graph)\n',s.index('def test_development_alias_after_validation_cannot_follow_automatic_integration'))
end=s.index('            assert graph.record()["tickets"]["03"]["state"]',start)
s=s[:start]+'''    configure_plan(graph)
    ready = graph.home / "candidate-ready"
    release = graph.home / "candidate-release"
    suite = graph.home / "candidate-barrier.py"
    suite.write_text(
        "import os, subprocess, sys, time\\nfrom pathlib import Path\\n"
        f"subprocess.run({graph.config['suite']!r}, check=True)\\n"
        "if os.environ['TICKET_HARNESS_STAGE'] == 'candidate' "
        "and Path('last-ticket').read_text() == '03':\\n"
        f"    Path({str(ready)!r}).write_text('checked')\\n"
        "    deadline = time.monotonic() + 20\\n"
        f"    while not Path({str(release)!r}).exists():\\n"
        "        if time.monotonic() >= deadline:\\n"
        "            raise TimeoutError('candidate observer did not release suite')\\n"
        "        time.sleep(0.001)\\n"
    )
    graph.config["suite"] = [sys.executable, str(suite)]
    with foreground(graph) as process:
        # Hold the first checked candidate until the observer confirms the owner
        # is stopped. Polling a completed gate can miss its integration interval.
        wait_for(graph, process, lambda record: ready.exists())
        with pause_after_git(
            process,
            ["for-each-ref", "--format=%(symref)", "refs/heads/dev"],
            transaction_open=after_prepare,
            trigger=lambda: release.write_text("observer armed"),
        ):
'''+s[end:]
p.write_text(s)
