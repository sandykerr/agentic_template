from pathlib import Path
import json,os,subprocess,sys,time
out=Path('.scratch/ticket-harness/evidence/m1-human-review-01')
env=dict(os.environ,PYTHONPATH='/tmp/ticket23-tools')
commands=[[sys.executable,'-m','mypy'],[sys.executable,'-m','ruff','check','ticket_harness','tests','examples'],[sys.executable,'-m','ruff','format','--check','ticket_harness','tests','examples'],['git','diff','--check']]
results=[]
for i,cmd in enumerate(commands):
    start=time.monotonic(); log=out/f'static-{i}.log'
    with log.open('w') as stream:
        result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
    item=dict(command=cmd,exit=result.returncode,seconds=time.monotonic()-start,log=log.name)
    results.append(item); print(json.dumps(item),flush=True)
    (out/'static-results.json').write_text(json.dumps(results,indent=2)+'\n')
    if result.returncode:
        print(log.read_text(),flush=True);sys.exit(result.returncode)
