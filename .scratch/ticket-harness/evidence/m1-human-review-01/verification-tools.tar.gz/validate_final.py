from pathlib import Path
import hashlib,json,re,subprocess,tarfile,xml.etree.ElementTree as ET
root=Path.cwd();out=root/'.scratch/ticket-harness/evidence/m1-human-review-01'
source=json.loads((out/'renewed-source.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in source['sha256'].items())
result=json.loads((out/'renewed-suite-result.json').read_text())
assert result['exit']==0 and not result['interrupted'] and result['source_unchanged']
rows=[json.loads(s) for s in (out/'renewed-reports.jsonl').read_text().splitlines()]
assert not [r for r in rows if r['outcome']=='failed']
calls=[r for r in rows if r['when']=='call']
assert len(calls)==559 and all(r['outcome']=='passed' for r in calls)
junit=ET.parse(out/'renewed-pytest.xml').getroot()
cases=junit.findall('.//testcase');assert len(cases)==559
assert not junit.findall('.//failure') and not junit.findall('.//error')
statics=json.loads((out/'renewed-static-results.json').read_text())
assert len(statics)==4 and all(r['exit']==0 for r in statics)
with tarfile.open(out/'renewed-source.tar.gz') as tar:
    for name,h in source['sha256'].items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==h
worker=json.loads((out/'worker-evidence-manifest.json').read_text())
assert hashlib.sha256((out/worker['archive']).read_bytes()).hexdigest()==worker['archive_sha256']
with tarfile.open(out/worker['archive']) as tar:
    for name,info in worker['files'].items():
        raw=tar.extractfile(name).read();assert len(raw)==info['bytes'] and hashlib.sha256(raw).hexdigest()==info['sha256']
raw=Path('/tmp/m1-human-review-20261112/renewed-suite-observations')
assert hashlib.sha256((out/result['archive']).read_bytes()).hexdigest()==result['archive_sha256']
archive_files=0
with tarfile.open(out/result['archive']) as tar:
    for item in tar.getmembers():
        if item.isfile():
            data=tar.extractfile(item).read();path=raw/Path(item.name).relative_to('observations')
            assert data==path.read_bytes();archive_files+=1
assert archive_files==result['observation_files']
review=root/'docs/human_qa/m1_review.md'
prefix=review.read_text().split('## Response and implementation',1)[0].encode()
provenance=json.loads((out/'human-review-provenance.json').read_text())
assert hashlib.sha256(prefix).hexdigest()==provenance['current_review_prefix_sha256']
checked=[]
for p in [review,out/'root-01.md',root/'.scratch/ticket-harness/reviews/M1-human-readability-01.md']:
    assert p.exists()
    for dest in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
        if '://' in dest:continue
        filename=dest.split('#')[0]
        if filename:
            assert (p.parent/filename).exists(),(str(p),dest);checked.append(dest)
original=Path('/tmp/m1-human-review-20261112/preexisting.patch').read_bytes()
current=subprocess.check_output(['git','diff','--binary'])
def sections(raw):
    return {piece.split(b'\n',1)[0].split(b' b/',1)[1].decode():b'diff --git '+piece for piece in raw.split(b'diff --git ')[1:]}
old,new=sections(original),sections(current)
allowed={'tests/test_milestones.py','tests/test_qa_promotion.py','next_agent_prompt.md','.scratch/ticket-harness/reviews/README.md'}
protected=[]
for path,patch in old.items():
    if path in allowed or path.startswith('ticket_harness/'):continue
    assert new.get(path)==patch,path;protected.append(path)
for path in new:assert path in old or path in allowed or path.startswith('ticket_harness/'),path
assert subprocess.run(['git','diff','--check'],capture_output=True).returncode==0
assert hashlib.sha256((root/'.scratch/ticket-harness/evidence/m1-qa-01/standards-01-original.md').read_bytes()).hexdigest()=='db0d35222d6b96030ed70feb5c662a2bba28a87825e707251f3f6b3bb004d002'
summary=dict(verified_source_files=len(source['sha256']),full_suite_passed=len(calls),static_gates_passed=len(statics),worker_files_readback=len(worker['files']),suite_observation_files_readback=archive_files,human_review_prefix_preserved=True,report_links_checked=len(checked),preexisting_tracked_diffs_preserved=len(protected),whitespace='passed',original_cumulative_report_unchanged=True,cumulative_F1='open; not repaired',milestone_accepted=False)
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
