# 1: Change value

Status: ready-for-agent
Blocked by: None (can start immediately).
Checks: ticket

## Acceptance criteria

* [x] value.txt contains 2.

## Comments
Status: Done
