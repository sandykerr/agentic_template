# 01: Change value

**Status:** ready-for-agent
**Blocked by:** None

Status: ready-for-human
## Acceptance criteria

- [ ] value.txt contains 2.
