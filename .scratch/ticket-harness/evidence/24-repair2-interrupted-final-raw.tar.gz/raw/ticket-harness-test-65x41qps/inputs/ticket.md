# 01: Work 01

Worker reasoning: High
Status: ready-for-agent
Blocked by: None
Checks: ticket

## Acceptance criteria

- [ ] Deliver work 01.
