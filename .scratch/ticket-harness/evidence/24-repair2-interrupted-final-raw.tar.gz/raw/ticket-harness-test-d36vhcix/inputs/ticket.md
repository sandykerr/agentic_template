# 01: Change value


**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.
