# 01: Change value

**Status:** ready-for-agent
**Blocked by:** None

Title: Wrong title
## Acceptance criteria

- [ ] value.txt contains 2.
