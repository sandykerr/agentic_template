# 01: Change value

**Status:** ready-for-agent
**Blocked by:** None

ID: 99
## Acceptance criteria

- [ ] value.txt contains 2.
