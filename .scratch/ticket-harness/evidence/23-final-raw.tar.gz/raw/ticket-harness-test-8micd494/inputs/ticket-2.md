# 03: Work 03

**Plan version:** v1
**Milestone:** M1
**Worker reasoning:** High
Status: ready-for-agent
Blocked by: None
Checks: other

## Acceptance criteria

- [ ] Deliver work 03.
