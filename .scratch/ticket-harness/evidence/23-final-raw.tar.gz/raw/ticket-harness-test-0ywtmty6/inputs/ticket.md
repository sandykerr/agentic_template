# 01: Change value

**Status:** ready-for-agent


## Acceptance criteria

- [ ] value.txt contains 2.
