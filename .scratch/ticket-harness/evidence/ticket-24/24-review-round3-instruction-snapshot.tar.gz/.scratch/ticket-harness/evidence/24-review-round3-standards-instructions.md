# Standards axis instructions

Read `24-review-round3-common.md` in this evidence directory first and follow its full context/independence contract.

Apply OOP `.agents/skills/microsoft/microsoft_oop/SKILL.md`, codebase-design `.agents/skills/matt-pocock/codebase-design/SKILL.md`, and test-strategy. Standards sources are AGENTS, domain/ADRs, approved spec/contracts, repo guidance and wayfinding; no root CONTRIBUTING/CODING_STANDARDS file exists. Trace beyond changed hunks and assess all relevant state ownership. Assess costly/redundant/brittle tests, fixture isolation/cleanup/reliability with concrete consequences; preferences remain optional. Tool-enforced issues excluded. Upstream smell baseline (heuristics; repo overrides; not automatic findings):

Each smell reads *what it is* → *how to fix*; match it against the diff:

- **Mysterious Name**: a function, variable, or type whose name doesn't reveal what it does or holds. → rename it; if no honest name comes, the design's murky.
- **Duplicated Code**: the same logic shape appears in more than one hunk or file in the change. → extract the shared shape, call it from both.
- **Feature Envy**: a method that reaches into another object's data more than its own. → move the method onto the data it envies.
- **Data Clumps**: the same few fields or params keep travelling together (a type wanting to be born). → bundle them into one type, pass that.
- **Primitive Obsession**: a primitive or string standing in for a domain concept that deserves its own type. → give the concept its own small type.
- **Repeated Switches**: the same `switch`/`if`-cascade on the same type recurs across the change. → replace with polymorphism, or one map both sites share.
- **Shotgun Surgery**: one logical change forces scattered edits across many files in the diff. → gather what changes together into one module.
- **Divergent Change**: one file or module is edited for several unrelated reasons. → split so each module changes for one reason.
- **Speculative Generality**: abstraction, parameters, or hooks added for needs the spec doesn't have. → delete it; inline back until a real need shows.
- **Message Chains**: long `a.b().c().d()` navigation the caller shouldn't depend on. → hide the walk behind one method on the first object.
- **Middle Man**: a class or function that mostly just delegates onward. → cut it, call the real target direct.
- **Refused Bequest**: a subclass or implementer that ignores or overrides most of what it inherits. → drop the inheritance, use composition.


Save your COMPLETE original at `.scratch/ticket-harness/evidence/24-review-standards-03.md` (must not exist beforehand), optionally your own audit at24-review-standards-03-audit.json. Do not read current sibling report. Return exact paths, counts and prior-key verification. Root owns capture/dispositions.
