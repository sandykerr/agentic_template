import json, os, subprocess, sys
from pathlib import Path
a = json.load(sys.stdin)
home = Path('/tmp/ticket-harness-test-h3xlit3z')
lock = home / 'active-process'
fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
os.close(fd)
def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()
record = json.loads((Path.cwd().parents[1] / 'run.json').read_text())
event = dict(ticket=a['ticket'], role=a['role'], attempt=a['attempt'],
    head=git('rev-parse', 'HEAD'), integration=git('rev-parse', 'integration'),
    states=record.get('tickets'), base=a['base_revision'], pid=os.getpid())
with (home / 'launches.jsonl').open('a') as out:
    out.write(json.dumps(dict(event, event='start')) + '\n')
assert a['inputs']['ticket'].startswith('# ' + a['ticket'] + ':')
r = {k: a[k] for k in ('role', 'ticket', 'attempt', 'base_revision', 'revision')}
r['pid'] = os.getpid()
if a['role'] == 'implementation':
    Path('work-' + a['ticket']).write_text('delivered ' + a['ticket'] + '\n')
    Path('last-ticket').write_text(a['ticket'])
    r.update(result='submitted', summary='Delivered ticket', changed_files=[],
        checks=[], acceptance_evidence=['Delivered cumulative work'], unresolved_questions=[])
else:
    r['findings'] = []
with (home / 'launches.jsonl').open('a') as out:
    out.write(json.dumps(dict(event, event='end')) + '\n')
lock.unlink()
print(json.dumps(r))
