# 01: Change value

**Status:** needs-info
**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.
