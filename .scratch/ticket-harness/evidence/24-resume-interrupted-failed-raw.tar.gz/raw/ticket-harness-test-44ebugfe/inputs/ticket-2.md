# 03: Work 03

Worker reasoning: v1
Worker reasoning: v1
Status: ready-for-agent
Blocked by: None
Checks: other

## Acceptance criteria

- [ ] Deliver work 03.
