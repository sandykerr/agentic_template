# 02: Follow-up
Status: ready-for-agent
Blocked by: [01: Change value](01-value.md)

## Acceptance criteria
- [ ] value.txt contains 3.
