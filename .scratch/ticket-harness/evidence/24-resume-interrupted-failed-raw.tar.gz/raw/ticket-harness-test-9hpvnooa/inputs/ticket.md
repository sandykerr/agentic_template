# 01: Change value

**Status:** ready-for-human
**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.
