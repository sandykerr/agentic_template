# 01: Change value

# 02: Another ticket
**Status:** ready-for-agent
**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.
