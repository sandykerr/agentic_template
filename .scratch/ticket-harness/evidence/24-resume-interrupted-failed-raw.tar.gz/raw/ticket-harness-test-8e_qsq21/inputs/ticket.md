# 01: Change value
Status: ready-for-agent
Blocked by: None

```markdown
## Acceptance criteria
- [ ] Just an example.
```
