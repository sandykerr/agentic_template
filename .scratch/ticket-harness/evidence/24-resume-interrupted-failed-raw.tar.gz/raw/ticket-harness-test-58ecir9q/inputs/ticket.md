# 01: Change value

**Status:** needs-triage
**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.
