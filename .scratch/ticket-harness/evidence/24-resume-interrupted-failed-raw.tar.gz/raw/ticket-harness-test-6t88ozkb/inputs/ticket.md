# 01: Change value

**Status:** ready-for-agent
**Blocked by:** None

Checks: missing
## Acceptance criteria

- [ ] value.txt contains 2.
