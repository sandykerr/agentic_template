# 02: Work 02

Status: ready-for-human
Blocked by: 03, 04
Checks: ticket

## Acceptance criteria

- [ ] Deliver work 02.
