# 01: Work 01

Status: ready-for-agent
Blocked by: 02
Checks: ticket

## Acceptance criteria

- [ ] Deliver work 01.
