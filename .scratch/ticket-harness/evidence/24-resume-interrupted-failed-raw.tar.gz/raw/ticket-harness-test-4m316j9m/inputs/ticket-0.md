# 04: Work 04

Status: ready-for-agent
Blocked by: None
Checks: ticket

## Acceptance criteria

- [ ] Deliver work 04.
