# 01: Change value

**Status:** ready-for-agent
**Blocked by:** [02: Other work](02-other.md)

## Acceptance criteria

- [ ] value.txt contains 2.
