# 01: Change value

**Status:** ready-for-agent
**Blocked by:** None

Checks: ticket
## Acceptance criteria

- [ ] value.txt contains 2.
