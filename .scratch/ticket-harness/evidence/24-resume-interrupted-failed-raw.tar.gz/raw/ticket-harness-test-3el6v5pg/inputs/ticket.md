---
id: 99
status: ready-for-human
---
# 01: Change value

**Status:** ready-for-agent
**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.
