# 01: Change value

**Status:** ready-for-agent
**Blocked by:** [02: Other work](01-value.md)

## Acceptance criteria

- [ ] value.txt contains 2.
