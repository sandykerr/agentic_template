# 02: Other work

**Status:** ready-for-agent
**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.
