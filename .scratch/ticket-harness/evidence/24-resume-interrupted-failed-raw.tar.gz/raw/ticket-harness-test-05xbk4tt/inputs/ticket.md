# 06: Follow up
Status: ready-for-agent
Blocked by: 03
Checks: ticket

## Acceptance criteria
- [ ] Follow up.
