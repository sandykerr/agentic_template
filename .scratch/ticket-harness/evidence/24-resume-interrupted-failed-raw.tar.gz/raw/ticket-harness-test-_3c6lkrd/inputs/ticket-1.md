# 02: Other work

**Status:** ready-for-human
**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.
