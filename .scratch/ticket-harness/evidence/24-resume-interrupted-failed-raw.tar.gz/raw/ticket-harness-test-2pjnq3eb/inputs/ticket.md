# 02: Follow-up
Status: ready-for-agent
Blocked by: 01

## Acceptance criteria
- [ ] Follow-up works.
