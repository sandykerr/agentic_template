# 01: Change value

**Status:** ready-for-agent
**Blocked by:** 02: Incorrect title

## Acceptance criteria

- [ ] value.txt contains 2.
