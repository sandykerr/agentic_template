# 01: Change value

**Status:** ready-for-agent
**Blocked by:** None

## Acceptance criteria

- [ ] value.txt contains 2.

# 02: Hidden second ticket
