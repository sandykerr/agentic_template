approved input
