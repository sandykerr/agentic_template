import os, subprocess
from pathlib import Path
stage = os.environ['TICKET_HARNESS_STAGE']
print(stage, subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip())
if stage != 'baseline':
    ticket = Path('last-ticket').read_text()
    assert Path('work-' + ticket).read_text() == 'delivered ' + ticket + '\n'
    for dep in {'02': ['01', '04'], '04': ['01']}.get(ticket, []):
        assert Path('work-' + dep).exists()
