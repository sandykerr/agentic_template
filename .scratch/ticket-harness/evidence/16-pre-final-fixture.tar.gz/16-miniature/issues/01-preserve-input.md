# 01: Preserve captured input (synthetic)

**Status:** ready-for-agent

**Plan:** synthetic-plan-v1, synthetic approval assumed only for this example.
**Milestone:** [MX](../milestones.md).

Authorized repair changes the two synthetic source statements to yes. Initial
source `9d00b4a8c86fd438e26a923f8e394fc2f4c06c28`, repair `e08236004b30e2ca0b7f9d56b6db7f1c4971b8d4`, later changed source `35a194a718a0bea7686b8762762aedb043aa0a09` are [saved](../evidence/commits.md).
This readiness label is unaffected by the review lifecycle.

## History

- [Ticket assessment](../reviews/ticket-01.md), [original concern](../evidence/spec-01.md#f1),
  [repair and verification](../reviews/history.md#e03).
- [Cross-ticket assessment](../reviews/architecture-MX.md) links this ticket and follow-up.
