# 06: Follow up
Status: ready-for-agent
Blocked by: 01, 02, 03, 04
Checks: ticket

## Acceptance criteria
- [ ] Deliver follow up.
