# 02: Other work

**Status:** ready-for-agent
**Blocked by:** 01

## Acceptance criteria

- [ ] value.txt contains 2.
