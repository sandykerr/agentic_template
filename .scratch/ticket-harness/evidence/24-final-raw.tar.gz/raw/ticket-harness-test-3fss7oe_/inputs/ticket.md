# 01: Change value

**Status:** ready-for-agent
**Blocked by:** 02

## Acceptance criteria

- [ ] value.txt contains 2.
