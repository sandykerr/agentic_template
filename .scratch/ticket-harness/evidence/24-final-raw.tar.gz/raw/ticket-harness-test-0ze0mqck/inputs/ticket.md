# 01: Work 01

Status: ready-for-agent
Blocked by: 05
Checks: ticket

## Acceptance criteria

- [ ] Deliver work 01.
