# 05: Human context

Status: ready-for-human
Blocked by: 02

## Acceptance criteria

- [ ] Human work.
