# 02: Work 02

Status: ready-for-agent
Blocked by: 03, 04, 05
Checks: ticket

## Acceptance criteria

- [ ] Deliver work 02.
